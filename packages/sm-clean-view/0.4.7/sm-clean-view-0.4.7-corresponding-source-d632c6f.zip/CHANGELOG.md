- [Remove access to filter creation in popup when "no filtering"](https://github.com/gorhill/uBlock/commit/610c2431dc)
- [De-duplicate scriptlet functions across rulesets](https://github.com/gorhill/uBlock/commit/b711687470)
- Updated filter lists

----------

### 2026.1006.1931

- Updated filter lists

----------

### 2026.930.1227

- Updated filter lists

----------

### 2026.926.2202

- [Add support for editor commands as buttons](https://github.com/gorhill/uBlock/commit/a3185dc14a)
- [Improve detection of non-website pages](https://github.com/gorhill/uBlock/commit/815627024c)
- [Add support for web_accessible_resources-based scriptlet filters](https://github.com/gorhill/uBlock/commit/bf7c4764fc)
- Updated filter lists

----------

### 2026.920.1710

- [Preemptively inject user styles locally](https://github.com/gorhill/uBlock/commit/272007789b)
- [Move managed custom scriptlet filters to sandbox](https://github.com/gorhill/uBlock/commit/cd8b675634)
- [Make popup panel ready to deal with non-website web pages](https://github.com/gorhill/uBlock/commit/dd5c1bae63)
- Updated filter lists

----------

### 2026.914.1325

- Updated filter lists

----------

### 2026.907.2003

- [Fix admin `noFiltering` not taking precedence over user changes](https://github.com/gorhill/uBlock/commit/6edba1597f)
- Updated filter lists

----------

### 2026.901.1442

- Updated filter lists

----------

### 2026.825.1619

- [Replace List-KR with filterslists-KO](https://github.com/gorhill/uBlock/commit/20d3c5b9d0)
- [Add missing configuration items from backup/restore](https://github.com/gorhill/uBlock/commit/39a0106ffc)
- [Fix "Filter lists" rendering on reset/restore](https://github.com/gorhill/uBlock/commit/f94bf63c91)
- Updated filter lists

----------

### 2026.819.1210

- [Fix performance issue when importing large lists](https://github.com/gorhill/uBlock/commit/10ae629288)
- Updated filter lists

----------

### 2026.818.1458 

- [Reject `popup` filters with excluded origins](https://github.com/gorhill/uBlock/commit/37a2ce19d3)
- [Mind `to=` option when converting `popup` filters](https://github.com/gorhill/uBlock/commit/c68df492fd)
- Updated filter lists

----------

### 2026.812.1211

- Updated filter lists

----------

### 2026.811.1529

- [Add support for broad scriptlet exception (`#@#js()`)](https://github.com/gorhill/uBlock/commit/fd67cde545)
- [Fix "Imported lists" section not updating properly](https://github.com/gorhill/uBlock/commit/2e13a766c5)
- [Patch `removeParams` rules with `main_frame` & `initiatorDomains` properties](https://github.com/gorhill/uBlock/commit/a873fd2b29)
- [Add "user scripts" permission warning for sandbox filters](https://github.com/gorhill/uBlock/commit/5c34167eb4)
- Updated filter lists

----------

### 2026.804.1652

- Updated filter lists

----------

### 2026.729.1529

- [Fix unintended skipping of applying enabled rulesets](https://github.com/gorhill/uBlock/commit/1b782e417e)
- [Add link to documentation](https://github.com/gorhill/uBlock/commit/7a614ccf5d)
- Updated filter lists

----------

### 2026.723.1724

- [Add support to move stock lists to imported lists](https://github.com/gorhill/uBlock/commit/64deacc98c)
- [Hide list group which have no list](https://github.com/gorhill/uBlock/commit/52e66ff81a)
- Updated filter lists

----------

### 2026.714.1952

- Updated filter lists

----------

### 2026.713.1408

- [Cache fetched lists on a per platform basis](https://github.com/gorhill/uBlock/commit/031b52ba4d)
- Updated filter lists

----------

### 2026.711.25

- [Add support for excluded hostnames in `popup` filters](https://github.com/gorhill/uBlock/commit/0d0f4d6406)
- [Fix processing of preparse directives in imported lists](https://github.com/gorhill/uBlock/commit/4dae710c34)
- Updated filter lists

----------

### 2026.705.2152

- [Discard rules with `topDomains` condition when not supported](https://github.com/gorhill/uBlock/commit/993d42c374)
- Updated filter lists

----------

### 2026.628.2035

- [Excluded resource types must exclude `main_frame`](https://github.com/gorhill/uBlock/commit/a2ed727d21)
- Updated filter lists

----------

### 2026.625.2148

- [Fix improperly discarding trusted filters in mixed lists](https://github.com/gorhill/uBlock/commit/8dff81c5a0)
- [Fix mismanagement of alarms potentially causing endless async loop](https://github.com/gorhill/uBlock/commit/e6f5b9a23a)
- Updated filter lists

----------

### 2026.625.1633

- [Exclude redirect resource `click2load.html`](https://github.com/gorhill/uBlock/commit/3bf5076f9b)
- [Fix priority of `important` redirects in locally-compiled filters](https://github.com/gorhill/uBlock/commit/a532fb11cd)
- [Add ability to view DNR rules of imported lists in "Develop" pane](https://github.com/gorhill/uBlock/commit/fedd40fde3)
- [Compile imported lists using platform-specific resource types](https://github.com/gorhill/uBlock/commit/2803cf43c5)
- [Fix multiple issues with imported lists feature](https://github.com/gorhill/uBlock/commit/1470ed462b)
- [Support specific-generic cosmetic and scriptlet user filters](https://github.com/gorhill/uBlock/commit/b29f6667e3)
- [Bring back "CERT.PL's Warning List"](https://github.com/gorhill/uBlock/commit/e46c59b792)
- [Fix conversion of `csp=`/`permissions=` exception filters](https://github.com/gorhill/uBlock/commit/90a13ba3e7)
- Updated filter lists

----------

### 2026.622.2316

- [Distinguish between need to update filters and need to update user scripts](https://github.com/gorhill/uBlock/commit/ef84281e77)
- [Fix regression when converting removeparam= filters to DNR rules](https://github.com/gorhill/uBlock/commit/9722c9e9cf)
- [Fix broken rendering of final URL in strict-block page](https://github.com/gorhill/uBlock/commit/f934cfb94b)
- [Imported lists are meant to work without requiring developer mode](https://github.com/gorhill/uBlock/commit/86532aa1b5)
- Updated filter lists

----------

### 2026.621.2046

- [Add missing `browser` import](https://github.com/gorhill/uBlock/commit/83f0c2b64a)
- Updated filter lists

----------

### 2026.621.1813

- [firefox] [Fix "Develop" editor being unscrollable](https://github.com/gorhill/uBlock/commit/b20f355278)
- [Use alarms API to manage low-priority deferred tasks](https://github.com/gorhill/uBlock/commit/174012e57d)
- [Manually check for userScripts permission changes](https://github.com/gorhill/uBlock/commit/bf405035a9)
- [edge] [Remove the now possibly unnecessary patching of rulesets](https://github.com/gorhill/uBlock/commit/8839a9f7a8)
- [Add ability to subscribe to filter lists from remote servers](https://github.com/gorhill/uBlock/commit/06deb19dfa)
- Updated filter lists

----------

### 2026.614.1502

- [Wrap troubleshooting info into `details` tag](https://github.com/gorhill/uBlock/commit/d86c0a0675)
- [Fix conversion of `top=` option to DNR's `topDomains`](https://github.com/gorhill/uBlock/commit/560a59bd61)
- [Add `popupBlockMode` to admin-controlled settings](https://github.com/gorhill/uBlock/commit/3806141043)
- Updated filter lists

----------

### 2026.607.1724

- [Fix test for header matching when using negated value](https://github.com/gorhill/uBlock/commit/fa027e219a)
- [Fix binary search potentially not finding match in edge case](https://github.com/gorhill/uBlock/commit/bc5fa9fe9a)
- [Show all dynamic/session rules in Develop pane](https://github.com/gorhill/uBlock/commit/c1cadb35d9)
- [Prevent re-entrancy when compiling sandbox filters](https://github.com/gorhill/uBlock/commit/38eac0f0cb)
- Updated filter lists

----------

### 2026.529.1448

- [Add old-school filter editor for filter list authors](https://github.com/gorhill/uBlock/commit/2479484ba9)
- [Merge content scripts related to specific and procedural cosmetic filters](https://github.com/gorhill/uBlock/commit/2eebc7579d)
- Updated filter lists

----------

### 2026.516.1652

- [safari] [Fix Icon and delete metadata](https://github.com/uBlockOrigin/uBOL-home/commit/a932799467) by [6c67b9](https://github.com/6c67b9)
- [Bring popup blocking out of experimental status](https://github.com/gorhill/uBlock/commit/1083daaf82)
- [Allow custom cosmetic filters in embedded contexts](https://github.com/gorhill/uBlock/commit/8574d7162d)
- Updated filter lists

----------

### 2026.510.1607

- [Fix potentially residual user styles when previewing custom filters](https://github.com/gorhill/uBlock/commit/cc56504273)
- [Fix various quirks when previewing custom filters at creation time](https://github.com/gorhill/uBlock/commit/90e8212304)
- Updated filter lists

----------

### 2026.507.2008

- [Improve handling of manual editing of custom filters](https://github.com/gorhill/uBlock/commit/c2184441d8)
- [Fix regression when editing custom cosmetic `#...` filters](https://github.com/gorhill/uBlock/commit/27dbdb202e)
- [Improve contrast in dark mode](https://github.com/gorhill/uBlock/commit/7cd56887ff)
- [Fix custom cosmetic filtering when pages load from "Preload Top Hit"](https://github.com/gorhill/uBlock/commit/19ebbe73b9)
- Updated filter lists

----------

### 2026.504.2301

- [safari] [Fix regression in custom procedural cosmetic filters](https://github.com/gorhill/uBlock/commit/532f897ea8)
- Updated filter lists

----------

### 2026.504.1635

- [safari] [Fix cosmetic filtering when pages load from "Preload Top Hit"](https://github.com/gorhill/uBlock/commit/01ff17fe64)
- Updated filter lists

----------

### 2026.503.1521

- [Do not prevent creation of custom filters with no matching elements](https://github.com/gorhill/uBlock/commit/2434b8adad)
- [Fix support of CSS selectors with pseudo-elements in custom filters](https://github.com/gorhill/uBlock/commit/8e3c4c7f16)
- [Add support for highly generic cosmetic filter exceptions](https://github.com/gorhill/uBlock/commit/e2df53d0de)
- [Support copying/pasting custom filters](https://github.com/gorhill/uBlock/commit/11b749e0a3)
- Updated filter lists

----------

### 2026.426.1536

- [Fix various concurrency issues with "Restore" operation](https://github.com/gorhill/uBlock/commit/83c51b12b1)
- [Fix export button in "Custom filters" pane](https://github.com/gorhill/uBlock/commit/d8558aa56b)
- [Fix visual of "Remove a custom filter" for procedural filters](https://github.com/gorhill/uBlock/commit/bdc3bace25)
- [Add `topDomains`/`excludedTopDomains` conditions to DNR parser](https://github.com/gorhill/uBlock/commit/06eeaa2685)
- [Fix custom procedural filters when no ruleset enabled](https://github.com/gorhill/uBlock/commit/33dc8a7ff0)
- [safari] [Remove icons from Safari manifest](https://github.com/gorhill/uBlock/commit/04b1058007) by [sebastianlivoni](https://github.com/sebastianlivoni)
- Updated filter lists

----------

### 2026.422.1301

- [regression] [Fix potentially broken custom cosmetic filters](https://github.com/gorhill/uBlock/commit/8f504f6edf)
- [Add visual cue about invalid custom filters](https://github.com/gorhill/uBlock/commit/a7e2386219)
- [Launch offscreen document only when there are `+js()` filters](https://github.com/gorhill/uBlock/commit/35f8dab29c)
- Updated filter lists

----------

### 2026.419.1519

- [Explicitly exclude no-filtering sites from custom filters](https://github.com/gorhill/uBlock/commit/9b76445e8e)
- [Improve usability of "Custom filters" pane](https://github.com/gorhill/uBlock/commit/44d1eead39)
- [Add aria-label attributes in filtering mode slider](https://github.com/gorhill/uBlock/commit/cf93f2864a)
- [safari] [Upload new icons for Apple platform and delete old icons](https://github.com/uBlockOrigin/uBOL-home/commit/d5a1859e87) by [6c67b9](https://github.com/6c67b9)
- [chromium] [Add support for custom scriptlet filters](https://github.com/gorhill/uBlock/commit/46852ebd6f)
- Updated filter lists

----------

### 2026.412.1536

- Updated filter lists

----------

### 2026.405.2010

- [Fix `header=` conversion in custom DNR rules](https://github.com/gorhill/uBlock/commit/cfe54fc900)
- Updated filter lists

----------

### 2026.329.1951

- [Fix total count of DNR rules](https://github.com/gorhill/uBlock/commit/2bc251bcf9)
- Updated filter lists

----------

### 2026.323.2044

- [Fix regression leading to overzealous blocking](https://github.com/gorhill/uBlock/commit/751104a82c)
- Updated filter lists

----------

### 2026.322.1735

- [Add support for popup filtering](https://github.com/gorhill/uBlock/commit/12d7157d78)
    - To be safe against potential regression, popup filtering will be enforced only with default filtering mode set to _complete_ for the time being. Once well-tested, the feature will be enabled in _optimal_ mode.
- [safari] [Drop some lists from default rulesets](https://github.com/gorhill/uBlock/commit/8c5ddc08f9)
- [safari] [Expand `requestDomains` rules into multiple `urlFilter` rules](https://github.com/gorhill/uBlock/commit/82f87420d2)
- [Use low-priority "allow" rules for excepted modifier filters](https://github.com/gorhill/uBlock/commit/e7971e6bbd)
- [Add missing call to re-register content scripts](https://github.com/gorhill/uBlock/commit/fcb1eeee17)
- Updated filter lists

----------

### 2026.315.1814

- Updated filter lists

----------

### 2026.308.1810

- Updated filter lists

----------

### 2026.301.2014

- Updated filter lists

----------

### 2026.222.1657

- Updated filter lists

----------

### 2026.215.1801

- Updated filter lists

----------

### 2026.211.2314

- [Remove "Steven Black’s Unified Hosts" list](https://github.com/gorhill/uBlock/commit/8d9832b4d6)
- Updated filter lists

----------

### 2026.209.1522

- [Force register content scripts when none are found](https://github.com/gorhill/uBlock/commit/2b63dcdcb6)
- Updated filter lists

----------

### 2026.208.2004

- [Fix `removeparam` conversion](https://github.com/gorhill/uBlock/commit/93577ecca1)
- Updated filter lists

----------

### 2026.202.1612

- [safari] [Remove `image` from `removeparam`](https://github.com/gorhill/uBlock/commit/1ec05d4c0a)
- Updated filter lists

----------

### 2026.201.1924 

- [Add `image` to generic `removeparam` filters](https://github.com/gorhill/uBlock/commit/7aff7da77d)
- [Improve conversion of `removeparam` filters to DNR rules](https://github.com/gorhill/uBlock/commit/9b4f41df94)
- [Fix minor regression in reported troubleshooting info](https://github.com/gorhill/uBlock/commit/359cb070eb)
- Updated filter lists

----------

### 2026.125.1931

- [Add to troubleshooting info](https://github.com/gorhill/uBlock/commit/c6de97ceb7)
- [Fix regex in regex substitution rules](https://github.com/gorhill/uBlock/commit/f36dd3461b)
- Updated filter lists

----------

### 2026.118.1828

- [Fix equality test between two rulesets](https://github.com/gorhill/uBlock/commit/222f4fbbc1)
- [Add "Liste AR" to stock rulesets](https://github.com/gorhill/uBlock/commit/2ec2610f36)
- Updated filter lists

----------

### 2026.111.1925

- [Show spinner when filtering mode change takes long](https://github.com/gorhill/uBlock/commit/dfeb4e79ed)
- Updated filter lists

----------

### 2026.104.1656

- [Fix regression in conversion of `removeparam` filters](https://github.com/gorhill/uBlock/commit/329e99fd19)
- Updated filter lists

----------

### 2025.1230.2048

- [Fix "Proceed" button not working in strict-block page](https://github.com/gorhill/uBlock/commit/9b45333e0d)
- Updated filter lists

----------

### 2025.1229.1729

- [Add easylist AI suggestions to stock lists](https://github.com/gorhill/uBlock/commit/675ae7b5af)
- [Use parameter name as url filter where possible](https://github.com/gorhill/uBlock/commit/85f587162f)
- [Safari] [Increase local storage limit beyond 5 MB](https://github.com/gorhill/uBlock/commit/bda2a50ec8)
- [Add page-wide spinner when restoring/resetting settings](https://github.com/gorhill/uBlock/commit/f7f96140d9)
- [Add ability to reset to default settings](https://github.com/gorhill/uBlock/commit/6063d4f0ad)
- [Add support for regex-based extended filters](https://github.com/gorhill/uBlock/commit/377cf9d86b)
- Updated filter lists

----------

### 2025.1224.1544

- [Mind id/class attribute changes in generic cosmetic filterer](https://github.com/gorhill/uBlock/commit/c975fbb9d7)
- [Mind anscestor hostnames when evaluating host permissions](https://github.com/gorhill/uBlock/commit/4e0f47f11a)
- Updated filter lists

----------

### 2025.1217.1755

- [Fix behavior regression in scriptlets proxying `fetch()`](https://github.com/gorhill/uBlock/commit/cbf24a40b6)
- [Bypass cosmetic filtering when top context is set to no-filtering](https://github.com/gorhill/uBlock/commit/a23561d79e)
- Updated filter lists

----------

### 2025.1215.1455

- [Fix regression in `prevent-fetch` scriptlet](https://github.com/gorhill/uBlock/commits/2234d8aad2)
- Updated filter lists

----------

### 2025.1214.2112

- [Better validate hostnames in "Filtering mode details" editor](https://github.com/gorhill/uBlock/commit/621ad89c64)
- [Load specific cosmetic filtering data on-demand only](https://github.com/gorhill/uBlock/commit/0fb845d1ac)
- Updated filter lists


----------

### 2025.1207.2142

- [Re-work specific cosmetic filtering-related content scripts](https://github.com/gorhill/uBlock/commit/0aa0d81caf)
- [Generate at most two scriptlet-related files per rulesets](https://github.com/gorhill/uBlock/commit/6039ef2b6d)
- Updated filter lists

----------

### 2025.1130.1739

- [Improve automatically changing filtering mode](https://github.com/gorhill/uBlock/commit/cd814ee818)
- [Improve management of regex-based rules](https://github.com/gorhill/uBlock/commit/474723d9ca)
- Updated filter lists

----------

### 2025.1123.1640

- Updated filter lists

----------

### 2025.1116.1841

- [[firefox] Fix instanceof quirk; fine tune picker CSS](https://github.com/gorhill/uBlock/commit/d8fb800f30)
- [Auto reload current tab when permissions granted thru browser](https://github.com/gorhill/uBlock/commit/801b4679e9)
- Updated filter lists

----------

### 2025.1110.1551

- [safari] [Rewrite certain `main_frame` + `regexFilter` rules](https://github.com/gorhill/uBlock/commit/16c0f69853)
- Updated filter lists

----------

### 2025.1104.1637

- [Remove "Custom filters" pane when `picker` is forbidden](https://github.com/gorhill/uBlock/commit/9849b5f0b1)
- Updated filter lists

----------

### 2025.1019.1656

- [Automatically select optimal for newly allowed hosts](https://github.com/gorhill/uBlock/commit/511255f7c7)
- Updated filter lists

----------

### 2025.1012.1712

- [[safari] Force-reload rulesets when new browsing realm is seen](https://github.com/gorhill/uBlock/commit/8cc18c1089)
- [[safari] Workaround for user styles issue with bfcache](https://github.com/gorhill/uBlock/commit/22d2ecc472)
- [Improve details of troubleshooting info](https://github.com/gorhill/uBlock/commit/6623889920)
- Updated filter lists

----------

### 2025.928.1920

- [Avoid mouseenter/mouseleave on mobile devices](https://github.com/gorhill/uBlock/commit/be1502feb3)
- [Use manifest's path value to access static rulesets](https://github.com/gorhill/uBlock/commit/80cf4d9286)
- [Add ability to backup/restore settings](https://github.com/gorhill/uBlock/commit/2581004e8f)
- [Add dashboard pane to manage custom filters](https://github.com/gorhill/uBlock/commit/8af80be5b2)
- Updated filter lists

----------

### 2025.921.2008

- Updated filter lists

----------

### 2025.911.1335

- Updated filter lists

----------

### 2025.906.1308

- [Move redirect/removeParams/modifyHeaders rules to static rulesets](https://github.com/gorhill/uBlock/commit/4fbcabbc66)
- Updated filter lists

----------

###  2025.831.1814 

- [Ensure ui is visible even after failure](https://github.com/gorhill/uBlock/commit/d1a29d9899)
- [Merge AdGuard mobile filters with uBO's own mobile filters](https://github.com/gorhill/uBlock/commit/bc05f31cc2)
- Updated filter lists

----------

###  2025.825.1605 

- [Fix regression in managing redirect rules](https://github.com/gorhill/uBlock/commit/69fa0c2e09)
- Updated filter lists

----------

###  2025.824.1755 

- [Improve built-in parser to convert filters to DNR rules](https://github.com/gorhill/uBlock/commit/cb62e38f50)
- [Support custom filters using CSS pseudo-elements](https://github.com/gorhill/uBlock/commit/bc4e829427)
- Updated filter lists

----------

###  2025.818.1918

- [Add support for `regexSubstitution` from `uritransform`](https://github.com/gorhill/uBlock/commit/fad0af591f)
- [Improve internal error reporting in troubleshooting info](https://github.com/gorhill/uBlock/commit/25d9964b1e)
- [Fix unremovable custom filters created using older versions](https://github.com/gorhill/uBlock/commit/d54c4a7052)
- [Fix custom filter list being unscrollable](https://github.com/gorhill/uBlock/commit/718b3cdb97)
- Safari-specific:
  - [Workaround for `urlFilter` with path part ending with `^`](https://github.com/gorhill/uBlock/commit/5957656a5b)
  - [Do not inject CSS in embedded contexts](https://github.com/gorhill/uBlock/commit/4d2cfd1487)
- Updated filter lists

----------

### 2025.812.1339

- [Fix target URL when reporting from a strict-blocked page](https://github.com/gorhill/uBlock/commit/18f9acd844)
- [Share console error in troubleshooting information](https://github.com/gorhill/uBlock/commit/28ea00fd11)
- [Fix potentially unremovable custom filters](https://github.com/gorhill/uBlock/commit/a1a5f3690f)
- [Disable "strict blocking" by default in Safari](https://github.com/gorhill/uBlock/commit/19a3de901c)
- [Add "EasyList -- Notifications"](https://github.com/gorhill/uBlock/commit/cf70f2abbc)
- [Normalize request method names to lowercase in _Develop_ converter](https://github.com/gorhill/uBlock/commit/b9956a8d18)
- [Remove spurious console message in content script](https://github.com/gorhill/uBlock/commit/dfa47baddf)
- [Propagate DNR API errors to "Filter lists" pane](https://github.com/gorhill/uBlock/commit/93206e3241)
- [Fix browser permissions scanning at launch](https://github.com/gorhill/uBlock/commit/e645fe7468)
- [Add spinner as visual feedback when rulesets are being registered](https://github.com/gorhill/uBlock/commit/b6829698cc)
- [Prevent scrolling taking over moving dialog in picker](https://github.com/gorhill/uBlock/commit/2d2de3a53b)
- Updated filter lists

----------

### 2025.804.1547

- [Add support for custom procedural cosmetic filters](https://github.com/gorhill/uBlock/commit/32bf5ebde3)
- Updated filter lists

----------

### 2025.728.1406

- Updated filter lists

----------

### 2025.725.1450

- [Merge all `:style()` filters with procedural filters](https://github.com/gorhill/uBlock/commit/fed7f4a0b8)
- [Remove hostname normalization regarding filtering mode](https://github.com/gorhill/uBlock/commit/d7686a815e)
- [Fix potential exception in procedural operator `:matches-attr`](https://github.com/gorhill/uBlock/commit/e07e7bbd09)
- Updated filter lists

----------

### 2025.718.1921

- [Make the slider continuous rather than granular](https://github.com/gorhill/uBlock/commit/2c91bfc872)
- [Fix compatibility layer code](https://github.com/gorhill/uBlock/commit/cc7e7894c7)
- [Load procedural CSS code on demand](https://github.com/gorhill/uBlock/commit/e75e128a34)
- [Normalize rulesets read from package](https://github.com/gorhill/uBlock/commit/6bfa7245f3)
- [Adjust CSS for small display](https://github.com/gorhill/uBlock/commit/1a8238e03e)
- Updated filter lists

----------

### 2025.711.1256

- [Slightly rework popup panel layout](https://github.com/gorhill/uBlock/commit/f88ffcea04)
- Updated translations
- Updated filter lists

----------

### 2025.709.1622

- [Fix spurious filter conversion when pasting in editor](https://github.com/gorhill/uBlock/commit/6b7f929ec5)
- [Add support for custom CSS-based cosmetic filters](https://github.com/gorhill/uBlock/commit/0b0294af4f)
    - This is a first release of the feature, and as such only plain CSS-based filters are supported
- Updated filter lists

----------

### 2025.703.1440

- [Fix calculation of priority value when converting redirect filters](https://github.com/gorhill/uBlock/commit/eec2045645)
- [Fix regression in syntax highlighting of dark theme](https://github.com/gorhill/uBlock/commit/9c08e902bd)
- [Add access to troubleshooting info in About pane](https://github.com/gorhill/uBlock/commit/9bcfc8ff1c)
- [Fix newline assistant in mode editor](https://github.com/gorhill/uBlock/commit/27936f476e)
- Updated filter lists

----------

### 2025.624.1503

- [Add support to exclude lists from specific platforms](https://github.com/gorhill/uBlock/commit/e33bfc1f01)
- [Add ability to convert pasted filters to DNR rules](https://github.com/gorhill/uBlock/commit/e8fb0e1cc9)
- Updated filter lists

----------

### 2025.619.2143

- [Expand "Develop" pane](https://github.com/gorhill/uBlock/commit/b50341089d)
- Updated filter lists

----------

### 2025.612.1428

- [Collect/apply highly generic cosmetic exceptions across lists](https://github.com/gorhill/uBlock/commit/76d8b97869)
- [Properly refresh "Developer mode" checkbox on changes](https://github.com/gorhill/uBlock/commit/508138764d)
- Updated filter lists

----------

### 2025.605.2042

- Updated filter lists

----------

### 2025.603.859

- Updated filter lists

----------

### 2025.601.2131

- [Add support for custom DNR rules](https://github.com/gorhill/uBlock/commit/9339a75952)
    - Documentation: [Dashboard/Develop](https://github.com/uBlockOrigin/uBOL-home/wiki/Dashboard:-Develop)
- Updated filter lists

----------

### 2025.525.2314

- [Remove CERT.PL's Warning List](https://github.com/gorhill/uBlock/commit/686eefd6b0)
- [Add to troubleshooting info whether webext API calls failed](https://github.com/gorhill/uBlock/commit/2076d42239)
- [Give admins ability to prevent usage of zapper](https://github.com/gorhill/uBlock/commit/ecc64ae1)
- [Allow body element to vertically scroll](https://github.com/gorhill/uBlock/commit/4eae23065e)
- [Add support to convert header= option to DNR rules](https://github.com/gorhill/uBlock/commit/408b538e75)
- [Add browser info in troubleshooting data](https://github.com/gorhill/uBlock/commit/be8b6238d3)
- Updated filter lists

----------

### 2025.518.1611

- [Add "AdGuard -- Mobile Ads"](https://github.com/gorhill/uBlock/commit/ed10973717)
- [Use CodeMirror editor for list of no-filtering websites](https://github.com/gorhill/uBlock/commit/fd5da3fcd2)
- [Add ability to reset zapper selection on mobile devices](https://github.com/gorhill/uBlock/commit/d12e7817d2)
- Fine-tuning of various CSS properties
- Updated filter lists

----------

### 2025.512.1008

- [Mind discarded regex- or path-based entries when determining genericity](https://github.com/gorhill/uBlock/commit/3292f128d2)
- [Just force a reload when URL doesn't change](https://github.com/gorhill/uBlock/commit/3ff54b7f2a)
- [New approach to toggle toolbar icon not requiring extra permissions](https://github.com/gorhill/uBlock/commit/cc2760f4d6)
- Updated filter lists

----------

### 2025.5.5.1364

- [Fix strict-block exceptions causing duplicate rule ids](https://github.com/gorhill/uBlock/commit/58f5c53fbbf3e8173a84bd49ff38846f739f9346)
- Updated filter lists

----------

### 2025.5.4.1310

- Updated filter lists

----------

### 2025.4.27.1394

- [Add more managed policies](https://github.com/gorhill/uBlock/commit/a56e13156f)
- [Reflect no-filtering mode on the toolbar icon](https://github.com/gorhill/uBlock/commit/203b2235aa)
- [Separate EasyList, EasyPrivacy, PGL lists from uBlock filters](https://github.com/gorhill/uBlock/commit/0e5dec7fbb)
- Updated filter lists

----------

### 2025.4.21.839

- [Add admin setting `defaultFiltering`](https://github.com/gorhill/uBlock/commit/b8adf5b027)
- [Mitigate issues when hitting regex-based rules limit](https://github.com/gorhill/uBlock/commit/ec19e352b1)
- [Mind excluded `to=` hostnames in strict-block rules](https://github.com/gorhill/uBlock/commit/e20e6addf0)
- Updated filter lists

----------

### 2025.4.13.1188


- [Remove "permission-less" status at install time](https://github.com/gorhill/uBlock/commit/01e36db23a)
- Updated filter lists

----------

### 2025.4.6.1238

- Updated filter lists

----------

### 2025.4.1.700

- Emergency release due to bad filter potentially causing breakage
- Updated filter lists

----------

### 2025.3.30.1290

- Updated filter lists

----------

### 2025.3.23.1241

- [Bring back element zapper](https://github.com/gorhill/uBlock/commit/ab458b492a)
- [Add support for explicit `generichide` filter option](https://github.com/gorhill/uBlock/commit/98b011f64c)
- Updated filter lists

----------

### 2025.3.16.1281

- [Avoid re-entrance when registering content scripts](https://github.com/gorhill/uBlock/commit/c3187d85e8)
- [Improve generic cosmetic filtering](https://github.com/gorhill/uBlock/commit/a009623d97)
- [Minor changes to account for Edge build](https://github.com/gorhill/uBlock/commit/94db43c4ad)
- Updated filter lists

----------

### 2025.3.8.1350

- [Add support for ancestor context syntax in scriptlets](https://github.com/gorhill/uBlock/commit/d006fd06e7)
- [Add test suite list to available rulesets](https://github.com/gorhill/uBlock/commit/536f0fba25)
- [Convert `domain=` to `to=` for `csp=`/`permissions=` options](https://github.com/gorhill/uBlock/commit/1dbd280ba3)
- [Inject surveyor in frames](https://github.com/gorhill/uBlock/commit/b29ac98094)
- Updated filter lists

----------

### 2025.3.2.1298

- [Inject scriptlets in their intended target world](https://github.com/gorhill/uBlock/commit/8a6b12a319)
- Updated filter lists

----------

### 2025.2.23.1382

- [Remove obsolete Firefox workaround code](https://github.com/gorhill/uBlock/commit/02b78fb717)
- [Workaround for permissions dialog preventing proper mode change](https://github.com/gorhill/uBlock/commit/1d2378e74e)
- [Comply with Mozilla's "User Consent and Control"](https://github.com/gorhill/uBlock/commit/344539d793)
- [Fix incorrect hostname matching in urlskip-related code](https://github.com/gorhill/uBlock/commit/17c66030fe)
- Updated filter lists

----------

### 2025.2.19.775

- Updated filter lists

----------

### 2025.1.14.952

- Updated filter lists

----------

### 2025.1.7.268

- Updated filter lists

----------

### 2024.12.30.1320

- [Extend strict-blocking coverage; improve URL-skip behavior](https://github.com/gorhill/uBlock/commit/61922da24b)
- Updated filter lists

----------

### 2024.12.23.23

- [Enable OpenPhish ruleset by default](https://github.com/gorhill/uBlock/commit/89e44131a0)
- [Fix undue blocking of network requests for unfiltered sites](https://github.com/gorhill/uBlock/commit/c311315daa)
- Updated filter lists

----------

### 2024.12.15.1269

- Updated filter lists

----------

### 2024.12.10.932

- Updated filter lists

----------

### 2024.12.9.805

- [Fix regression in `set-constant` scriptlet](https://github.com/gorhill/uBlock/commit/2ccb01973e)
- Updated filter lists

----------

### 2024.12.8.1320

- [Ensure no generic cosmetic filters end up in specific realm](https://github.com/gorhill/uBlock/commit/56ba93700c)
- [Add `urlskip` support for strict-blocked page](https://github.com/gorhill/uBlock/commit/38390bab9c)
- [Implement strict blocking](https://github.com/gorhill/uBlock/commit/aa05cb32c6)
- Updated filter lists

----------

### 2024.12.2.22

- Updated filter lists

----------

### 2024.11.25.1376

- [Add ability for admins to disable features](https://github.com/gorhill/uBlock/commit/346b5ded7c)
- Updated filter lists

----------

### 2024.11.20.858

- [Fix flaw breaking scriptlets injection in optimal/basic mode](https://github.com/gorhill/uBlock/commit/6355a17187)
- Updated filter lists

----------

### 2024.11.19.1126

- [Fix force-reloading repeatedly when erroring at load time](https://github.com/gorhill/uBlock/commit/f3486275e9)
- [Batch changes thru dashboard UI to reduce worker's workload](https://github.com/gorhill/uBlock/commit/114acacd2e)
- [Fix `removeparam` potentially causing invalid DNR rules](https://github.com/gorhill/uBlock/commit/f9ce06977d)
- [Re-work dashboard: move list of rulesets in its own pane](https://github.com/gorhill/uBlock/commit/ae4754415c)
- [Add "RU AdList: Counters" to stock lists](https://github.com/gorhill/uBlock/commit/b4a5b411b5)
- [Slightly mitigate DNR flaw re. `removeparam` filters](https://github.com/gorhill/uBlock/commit/947602d4fe)
- Updated filter lists

----------

### 2024.11.15.813

- Updated filter lists

----------

### 2024.11.13.865

- [Remove obsolete Firefox-only workaround in scriptlet template](https://github.com/gorhill/uBlock/commit/2e745f9bfb)
- Updated filter lists

----------

### 2024.11.11.1298

- [Add support to add/remove rulesets through policies](https://github.com/gorhill/uBlock/commit/15dae359f7e9e75c49a86bad8a05ec3f7add3c35) (see [Managed settings / `rulesets`](https://github.com/uBlockOrigin/uBOL-home/wiki/Managed-settings#rulesets))
- Updated filter lists

----------

### 2024.11.3.1351

- Updated filter lists

----------

### 2024.10.28.929

- Updated filter lists

----------

### 2024.10.20.869

- [Fixed _Optimal_ or _Complete_ filtering potentially broken everywhere when enabling _AdGuard Chinese_ or _AdGuard Turskish_](https://github.com/gorhill/uBlock/commit/d4f15ca635)
- Updated filter lists

----------

### 2024.10.14.189

- Updated filter lists

----------

### 2024.10.6.1334

- Updated filter lists

----------

### 2024.9.29.1273

- [Add a _chat_ icon in popup panel to report filter issues](https://github.com/gorhill/uBlock/commit/560def639f)
- Updated filter lists

----------

### 2024.9.22.986

- Updated filter lists

----------

### 2024.9.12.1004

- Updated filter lists

----------

### 2024.9.1.1266

- Updated filter lists

----------

### 2024.8.21.996

- Updated filter lists

----------

### 2024.8.19.905

- Updated filter lists

----------

### 2024.8.12.902

- Updated filter lists

----------

### 2024.8.5.925

- Updated filter lists

----------
