location.replace(chrome.runtime.getURL('welcome.html#feedback'));
