export type CompanionState = "offline" | "connecting" | "online";
export type TaskStatus = "queued" | "running" | "paused" | "canceling" | "canceled" | "cancelled" | "completed" | "failed";
export type DownloadState = "waiting_destination" | "queued" | "connecting" | "downloading" | "canceling" | "canceled" | "paused" | "completed" | "failed";
export interface CompanionHealth { state: "online"; apiVersion: "v1"; service: { name: string; version: string }; bind: { host: "127.0.0.1"; port: number; scope: "loopback" }; authorization: string; message: string; }
export interface CompanionLifecycleStatus { state: "online"; service: { name: "Media Companion Core"; version: string }; pid: number; bind: { host: "127.0.0.1"; port: number; scope: "loopback" }; pairing: { state: "paired" | "unpaired"; sharedAuthorization: "sm-media-suite"; registeredOfficialOrigins: string[] }; runtime: { recordContainsSecrets: false }; }
export interface CapabilityDescriptor { available: boolean; status: string; reason: string; [key: string]: unknown; }
export interface CompanionCapabilities { apiVersion: "v1"; capabilities: { mediaProbe: CapabilityDescriptor; convert: CapabilityDescriptor; torrent: CapabilityDescriptor; tasks: CapabilityDescriptor }; security: Record<string, unknown>; }
export interface FileHandle { id: string; kind: string; name: string; bytes: number; contentType: string; createdAt: string; }
export interface TorrentFileSummary { index: number; name: string; bytes: number; path?: string; selected?: boolean; }
export interface ControlledOutput { id: string; kind: string; name: string; bytes: number; }
export interface MediaStreamSummary { codec?: string; width?: number; height?: number; }
export interface MediaPlanResponse { plan?: { route?: string; estimatedSpeed?: string; estimatedEnergy?: string; estimatedOutputBytes?: number }; }
export interface DownloadLocation { id: "companion-controlled"; label: string; kind: "controlled"; customDirectorySupported: false; }
export interface DownloadView { mode: "browser" | "companion"; state: DownloadState; file: TorrentFileSummary; location: { id: string; label: string }; bytesReceived: number; totalBytes: number; speed: number; peers: number; error: { code: string; message: string } | null; }
export interface BrowserDownloadTicket { url: string; expiresAt: string; suggestedName: string; bytes: number; }
export interface TaskSummary { id: string; kind: "convert" | "analysis" | "torrent"; status: TaskStatus; stage: string; progress: number; message: string; summary?: { source?: string; sourceMetadataTaskId?: string; networkScope?: string; deliveryMode?: "browser" | "companion"; locationId?: string; file?: { name?: string }; selectedFile?: TorrentFileSummary }; download?: DownloadView; result?: { metadataOnly?: boolean; infoHash?: string; name?: string; files?: TorrentFileSummary[]; selectedFile?: TorrentFileSummary; output?: ControlledOutput; downloadedBytes?: number; maxPeers?: number; deliveryMode?: "browser" | "companion"; browserStreamCompleted?: boolean; container?: string; durationSeconds?: number; video?: MediaStreamSummary[]; audio?: MediaStreamSummary[]; subtitles?: MediaStreamSummary[]; plan?: { route?: string } }; error?: { code: string; message: string }; createdAt: string; updatedAt: string; attempt: number; downloadedBytes?: number; totalBytes?: number; downloadSpeed?: number; uploadSpeed?: number; peers?: number; metadata?: { infoHash?: string; name?: string; files?: TorrentFileSummary[] }; }

export class CompanionApiError extends Error { constructor(public readonly code: string, message: string, public readonly status: number) { super(message); } }
export function resolveCompanionBaseUrl(): string { return "http://127.0.0.1:32145/api/v1"; }

export class HttpCompanionClient {
  private token = typeof sessionStorage === "undefined" ? "" : sessionStorage.getItem("media-companion-session") ?? "";
  constructor(private readonly baseUrl = resolveCompanionBaseUrl(), private readonly fetcher: typeof fetch = globalThis.fetch.bind(globalThis)) {}
  get paired(): boolean { return Boolean(this.token); }
  clearSession(): void { this.token = ""; if (typeof sessionStorage !== "undefined") sessionStorage.removeItem("media-companion-session"); }
  private storeSession(token: string): void { this.token = token; if (typeof sessionStorage !== "undefined") sessionStorage.setItem("media-companion-session", token); }
  private async request<T>(path: string, init: RequestInit = {}, requireSession = true): Promise<T> {
    const headers = new Headers(init.headers); headers.set("X-SM-Media-Origin", "chrome-extension://bhfamgbhdafngiepciphegchemmgblib"); if (requireSession && this.token) headers.set("Authorization", `Bearer ${this.token}`); if (init.body && !(init.body instanceof Blob) && !headers.has("Content-Type")) headers.set("Content-Type", "application/json");
    const localRequest = { ...init, headers, cache: "no-store", credentials: "omit", redirect: "error" } as RequestInit;
    const response = await this.fetcher(`${this.baseUrl}${path}`, localRequest); const value: unknown = await response.json().catch(() => ({}));
    if (!response.ok) { const failure = value && typeof value === "object" ? value as Record<string, unknown> : {}; if (response.status === 401) this.clearSession(); throw new CompanionApiError(typeof failure.error === "string" ? failure.error : `HTTP_${response.status}`, typeof failure.message === "string" ? failure.message : "Companion request failed.", response.status); }
    return value as T;
  }
  health(): Promise<CompanionHealth> { return this.request("/health", {}, false); }
  lifecycleStatus(): Promise<CompanionLifecycleStatus> { return this.request("/lifecycle/status", {}, false); }
  capabilities(): Promise<CompanionCapabilities> { return this.request("/capabilities", {}, false); }
  async requestPairing(clientName = "Media Toolkit"): Promise<{ pairingId?: string; pairingCode?: string; expiresAt?: string; inherited: boolean }> { const value = await this.request<{ pairingId?: string; pairingCode?: string; expiresAt?: string; token?: string; inherited?: boolean }>("/pairing/request", { method: "POST", body: JSON.stringify({ clientName }) }, false); if (value.token) this.storeSession(value.token); return { pairingId: value.pairingId, pairingCode: value.pairingCode, expiresAt: value.expiresAt, inherited: Boolean(value.inherited) }; }
  async confirmPairing(pairingId: string, code: string): Promise<void> { const value = await this.request<{ token: string }>("/pairing/confirm", { method: "POST", body: JSON.stringify({ pairingId, code }) }, false); this.storeSession(value.token); }
  async bootstrapSession(clientName = "Media Toolkit"): Promise<void> { const value = await this.request<{ token: string }>("/session/bootstrap", { method: "POST", body: JSON.stringify({ clientName }) }, false); this.storeSession(value.token); }
  session(): Promise<Record<string, unknown>> { return this.request("/session"); }
  async revokeSuiteAuthorization(): Promise<void> { await this.request("/suite/revoke", { method: "POST", body: "{}" }); this.clearSession(); }
  upload(file: File): Promise<FileHandle> { return this.request<{ file: FileHandle }>("/files", { method: "POST", headers: { "X-File-Name": file.name, "X-File-Type": file.type || "application/octet-stream", "Content-Length": String(file.size) }, body: file }).then(value => value.file); }
  plan(fileHandle: string, mode: string): Promise<MediaPlanResponse> { return this.request("/media/plan", { method: "POST", body: JSON.stringify({ fileHandle, mode }) }); }
  probe(fileHandle: string): Promise<TaskSummary> { return this.request<{ task: TaskSummary }>("/media/probe", { method: "POST", body: JSON.stringify({ fileHandle }) }).then(value => value.task); }
  convert(fileHandle: string, mode: string): Promise<TaskSummary> { return this.request<{ task: TaskSummary }>("/media/convert", { method: "POST", body: JSON.stringify({ fileHandle, mode }) }).then(value => value.task); }
  addTorrent(request: { magnet?: string; torrentHandle?: string; fileIndices?: number[]; metadataOnly?: boolean }): Promise<TaskSummary> { return this.request<{ task: TaskSummary }>("/torrents", { method: "POST", body: JSON.stringify(request) }).then(value => value.task); }
  downloadLocations(): Promise<DownloadLocation[]> { return this.request<{ locations: DownloadLocation[] }>("/download-locations").then(value => value.locations); }
  createTorrentDownload(metadataTaskId: string, fileIndex: number, mode: "browser" | "companion", locationId?: "companion-controlled"): Promise<{ task: TaskSummary; browserDownload?: BrowserDownloadTicket }> { const body = mode === "browser" ? { metadataTaskId, fileIndices: [fileIndex], deliveryMode: "browser" } : { metadataTaskId, fileIndices: [fileIndex], deliveryMode: "companion", locationId: locationId ?? "companion-controlled" }; return this.request("/torrents", { method: "POST", body: JSON.stringify(body) }); }
  downloadTorrentFile(metadataTaskId: string, fileIndex: number): Promise<TaskSummary> { return this.request<{ task: TaskSummary }>("/torrents", { method: "POST", body: JSON.stringify({ metadataTaskId, fileIndices: [fileIndex] }) }).then(value => value.task); }
  tasks(): Promise<TaskSummary[]> { return this.request<{ tasks: TaskSummary[] }>("/tasks").then(value => value.tasks); }
  taskAction(id: string, action: "pause" | "resume" | "cancel" | "retry"): Promise<TaskSummary> { return this.request<{ task: TaskSummary }>(`/tasks/${id}/${action}`, { method: "POST" }).then(value => value.task); }
}
