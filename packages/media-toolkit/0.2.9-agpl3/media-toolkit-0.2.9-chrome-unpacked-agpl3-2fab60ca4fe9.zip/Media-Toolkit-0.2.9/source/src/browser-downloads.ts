export type BrowserDownloadState = "waiting_destination" | "queued" | "connecting" | "downloading" | "canceling" | "canceled" | "paused" | "completed" | "failed";

export interface BrowserDownloadRecord {
  taskId: string;
  downloadId?: number;
  mode: "browser";
  name: string;
  bytesReceived: number;
  totalBytes: number;
  state: BrowserDownloadState;
  paused: boolean;
  canResume: boolean;
  error: { code: string; message: string } | null;
  cancelRequested: boolean;
  createdAt: string;
  updatedAt: string;
}

interface ChromeDownloadItem {
  id: number;
  state: "in_progress" | "interrupted" | "complete";
  paused: boolean;
  canResume?: boolean;
  bytesReceived: number;
  totalBytes: number;
  error?: string;
  filename?: string;
}

interface ChromeDownloadDelta {
  id: number;
  state?: { current: ChromeDownloadItem["state"] };
  paused?: { current: boolean };
  canResume?: { current: boolean };
  bytesReceived?: { current: number };
  totalBytes?: { current: number };
  error?: { current: string };
  filename?: { current: string };
}

export interface BrowserDownloadChrome {
  downloads: {
    download(options: { url: string; filename: string; saveAs: true; conflictAction: "uniquify" }): Promise<number>;
    cancel(id: number): Promise<void>;
    pause(id: number): Promise<void>;
    resume(id: number): Promise<void>;
    search(query: { id: number }): Promise<ChromeDownloadItem[]>;
    onCreated: { addListener(listener: (item: ChromeDownloadItem) => void): void };
    onChanged: { addListener(listener: (delta: ChromeDownloadDelta) => void): void };
    onErased: { addListener(listener: (id: number) => void): void };
  };
  storage: { local: { get(key: string): Promise<Record<string, unknown>>; set(value: Record<string, unknown>): Promise<void> } };
}

const STORAGE_KEY = "mediaToolkitBrowserDownloads";
const TERMINAL = new Set<BrowserDownloadState>(["canceled", "completed", "failed"]);
const now = () => new Date().toISOString();

export function sanitizeDownloadName(value: string): string {
  const leaf = String(value ?? "").replace(/\\/g, "/").split("/").at(-1)?.trim() ?? "";
  const cleaned = leaf.replace(/[<>:"|?*\u0000-\u001f]/g, "_").replace(/[. ]+$/g, "").slice(0, 120);
  if (!cleaned || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(cleaned)) return "download.bin";
  return cleaned;
}

export class BrowserDownloadController {
  readonly records = new Map<string, BrowserDownloadRecord>();

  constructor(private readonly chrome: BrowserDownloadChrome, private readonly emit: (record: BrowserDownloadRecord) => void = () => {}) {
    chrome.downloads.onCreated.addListener(item => { void this.reconcileItem(item); });
    chrome.downloads.onChanged.addListener(delta => { void this.reconcileDelta(delta); });
    chrome.downloads.onErased.addListener(id => { void this.markLost(id); });
  }

  async restore(): Promise<BrowserDownloadRecord[]> {
    const stored = await this.chrome.storage.local.get(STORAGE_KEY);
    const values = Array.isArray(stored[STORAGE_KEY]) ? stored[STORAGE_KEY] as BrowserDownloadRecord[] : [];
    for (const value of values) {
      if (!value || typeof value.taskId !== "string" || value.mode !== "browser" || typeof value.name !== "string") continue;
      this.records.set(value.taskId, { ...value, name: sanitizeDownloadName(value.name) });
    }
    for (const record of [...this.records.values()]) {
      if (record.downloadId === undefined || TERMINAL.has(record.state)) continue;
      const items = await this.chrome.downloads.search({ id: record.downloadId });
      if (items.length === 1) await this.applyItem(record, items[0]);
      else await this.failLost(record);
    }
    return this.list();
  }

  async start(input: { taskId: string; url: string; suggestedName: string; bytes: number }): Promise<BrowserDownloadRecord> {
    if (!/^http:\/\/127\.0\.0\.1:32145\/api\/v1\/browser-download\/[A-Za-z0-9_-]{32,}$/.test(input.url)) throw new Error("浏览器下载 URL 不是受信任的 Companion loopback ticket。");
    if (!input.taskId || !Number.isSafeInteger(input.bytes) || input.bytes < 0) throw new Error("浏览器下载元数据无效。");
    const name = sanitizeDownloadName(input.suggestedName);
    const timestamp = now();
    const record: BrowserDownloadRecord = { taskId: input.taskId, mode: "browser", name, bytesReceived: 0, totalBytes: input.bytes, state: "waiting_destination", paused: false, canResume: false, error: null, cancelRequested: false, createdAt: timestamp, updatedAt: timestamp };
    this.records.set(record.taskId, record); await this.persistAndEmit(record);
    try {
      record.downloadId = await this.chrome.downloads.download({ url: input.url, filename: name, saveAs: true, conflictAction: "uniquify" });
      record.state = "queued"; record.updatedAt = now(); await this.persistAndEmit(record);
      const items = await this.chrome.downloads.search({ id: record.downloadId });
      if (items.length === 1) await this.applyItem(record, items[0]);
      return structuredClone(record);
    } catch (error) {
      record.state = "failed"; record.error = { code: "BROWSER_DOWNLOAD_START_FAILED", message: error instanceof Error ? error.message : String(error) }; record.updatedAt = now(); await this.persistAndEmit(record); return structuredClone(record);
    }
  }

  async cancel(taskId: string): Promise<BrowserDownloadRecord> {
    const record = this.required(taskId);
    if (TERMINAL.has(record.state) || record.state === "canceling") return structuredClone(record);
    record.cancelRequested = true; record.state = "canceling"; record.updatedAt = now(); await this.persistAndEmit(record);
    if (record.downloadId === undefined) { record.state = "canceled"; record.updatedAt = now(); await this.persistAndEmit(record); return structuredClone(record); }
    await this.chrome.downloads.cancel(record.downloadId);
    const items = await this.chrome.downloads.search({ id: record.downloadId });
    if (items.length === 1) await this.applyItem(record, items[0]);
    else await this.failLost(record);
    return structuredClone(record);
  }

  async pause(taskId: string): Promise<BrowserDownloadRecord> { const record = this.required(taskId); if (record.downloadId === undefined || TERMINAL.has(record.state)) return structuredClone(record); await this.chrome.downloads.pause(record.downloadId); return this.query(taskId); }
  async resume(taskId: string): Promise<BrowserDownloadRecord> { const record = this.required(taskId); if (record.downloadId === undefined || TERMINAL.has(record.state)) return structuredClone(record); await this.chrome.downloads.resume(record.downloadId); return this.query(taskId); }
  async query(taskId: string): Promise<BrowserDownloadRecord> { const record = this.required(taskId); if (record.downloadId !== undefined && !TERMINAL.has(record.state)) { const items = await this.chrome.downloads.search({ id: record.downloadId }); if (items.length === 1) await this.applyItem(record, items[0]); else await this.failLost(record); } return structuredClone(record); }
  list(): BrowserDownloadRecord[] { return [...this.records.values()].map(record => structuredClone(record)); }

  private required(taskId: string): BrowserDownloadRecord { const record = this.records.get(taskId); if (!record) throw new Error("浏览器下载记录不存在。"); return record; }
  private async reconcileItem(item: ChromeDownloadItem): Promise<void> { const record = [...this.records.values()].find(value => value.downloadId === item.id); if (record) await this.applyItem(record, item); }
  private async reconcileDelta(delta: ChromeDownloadDelta): Promise<void> { const record = [...this.records.values()].find(value => value.downloadId === delta.id); if (!record) return; const items = await this.chrome.downloads.search({ id: delta.id }); if (items.length === 1) await this.applyItem(record, items[0]); else await this.failLost(record); }
  private async markLost(id: number): Promise<void> { const record = [...this.records.values()].find(value => value.downloadId === id); if (record && !TERMINAL.has(record.state)) await this.failLost(record); }

  private async applyItem(record: BrowserDownloadRecord, item: ChromeDownloadItem): Promise<void> {
    record.bytesReceived = Number.isFinite(item.bytesReceived) ? item.bytesReceived : record.bytesReceived;
    record.totalBytes = Number.isFinite(item.totalBytes) && item.totalBytes >= 0 ? item.totalBytes : record.totalBytes;
    record.paused = item.paused === true; record.canResume = item.canResume === true;
    if (item.state === "complete") { record.state = "completed"; record.error = null; }
    else if (item.state === "interrupted") {
      if (record.cancelRequested && item.error === "USER_CANCELED") { record.state = "canceled"; record.error = null; }
      else { record.state = "failed"; record.error = { code: item.error || "BROWSER_DOWNLOAD_INTERRUPTED", message: item.error || "Chrome 下载被中断。" }; }
    } else if (record.cancelRequested) record.state = "canceling";
    else if (item.paused) record.state = "paused";
    else record.state = record.bytesReceived > 0 ? "downloading" : "connecting";
    record.updatedAt = now(); await this.persistAndEmit(record);
  }

  private async failLost(record: BrowserDownloadRecord): Promise<void> { record.state = "failed"; record.error = { code: "BROWSER_DOWNLOAD_STATE_LOST", message: "Chrome 下载记录已丢失，无法推断完成。" }; record.updatedAt = now(); await this.persistAndEmit(record); }
  private async persistAndEmit(record: BrowserDownloadRecord): Promise<void> { const safe = [...this.records.values()].map(({ taskId, downloadId, mode, name, bytesReceived, totalBytes, state, paused, canResume, error, cancelRequested, createdAt, updatedAt }) => ({ taskId, downloadId, mode, name, bytesReceived, totalBytes, state, paused, canResume, error, cancelRequested, createdAt, updatedAt })); await this.chrome.storage.local.set({ [STORAGE_KEY]: safe }); this.emit(structuredClone(record)); }
}
