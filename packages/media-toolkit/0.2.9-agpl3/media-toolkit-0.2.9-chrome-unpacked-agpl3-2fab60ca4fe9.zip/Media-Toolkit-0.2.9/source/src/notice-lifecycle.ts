export interface NoticeScheduler {
  schedule(callback: () => void, delayMs: number): number;
  cancel(handle: number): void;
}

export interface NoticeView {
  show(message: string): void;
  hide(): void;
}

/** Keeps recovery guidance visible until a later user action or state change. */
export class NoticeLifecycle {
  private timeout: number | undefined;

  constructor(private readonly view: NoticeView, private readonly scheduler: NoticeScheduler) {}

  show(message: string, persistent = false): void {
    this.dismiss(false);
    this.view.show(message);
    if (!persistent) this.timeout = this.scheduler.schedule(() => this.dismiss(), 5000);
  }

  dismiss(hide = true): void {
    if (this.timeout !== undefined) this.scheduler.cancel(this.timeout);
    this.timeout = undefined;
    if (hide) this.view.hide();
  }
}
