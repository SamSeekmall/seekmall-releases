import { CompanionApiError, HttpCompanionClient, type CompanionCapabilities, type CompanionLifecycleStatus, type CompanionState, type DownloadLocation, type DownloadView, type FileHandle, type MediaPlanResponse, type TaskSummary } from "./companion-client.js";
import type { BrowserDownloadRecord } from "./browser-downloads.js";
import { initialRoute, isRoute, routes, type RouteId } from "./navigation.js";
import { NoticeLifecycle } from "./notice-lifecycle.js";

const client = new HttpCompanionClient(); const nav = document.querySelector<HTMLElement>("#main-nav")!; const content = document.querySelector<HTMLElement>("#page-content")!; const title = document.querySelector<HTMLElement>("#page-title")!; const notice = document.querySelector<HTMLElement>("#notice")!;
const noticeLifecycle = new NoticeLifecycle({ show: message => { notice.textContent = message; notice.hidden = false; }, hide: () => { notice.hidden = true; } }, { schedule: (callback, delayMs) => window.setTimeout(callback, delayMs), cancel: handle => window.clearTimeout(handle) });
let connectionState: CompanionState = "connecting"; let connectedService = "Media Companion"; let lifecycle: CompanionLifecycleStatus | undefined; let pairingId = ""; let pairingCode = ""; let selectedMedia: FileHandle | undefined; let planResult: MediaPlanResponse | undefined; let tasks: TaskSummary[] = []; let busy = false; let capabilities: CompanionCapabilities | undefined; let startRecoveryVisible = false; let lastConnectionError = ""; let downloadLocations: DownloadLocation[] = []; const torrentSelections = new Map<string, number>(); const torrentDeliveryModes = new Map<string, "browser" | "companion">(); const browserDownloads = new Map<string, BrowserDownloadRecord>();
interface ExtensionGlobal { chrome?: { runtime?: { sendMessage<T>(message: unknown): Promise<T>; onMessage: { addListener(listener: (message: unknown) => void): void } } } }
// 扩展页运行时由 Chrome 注入；普通类型检查环境可能没有该全局对象。
const extensionGlobal = globalThis as unknown as ExtensionGlobal; const extensionRuntime = extensionGlobal.chrome?.runtime;
async function backgroundMessage<T>(message: unknown): Promise<T> { if (!extensionRuntime) throw new Error("Chrome 下载后台不可用。"); return extensionRuntime.sendMessage<T>(message); }
const esc = (value: unknown) => String(value ?? "").replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]!);
const card = (heading: string, body: string, extra = "") => `<article class="card ${extra}"><h3>${heading}</h3>${body}</article>`;
const currentRoute = (): RouteId => initialRoute(location.hash); const mediaEngineAvailable = () => capabilities?.capabilities.convert.available === true && capabilities?.capabilities.mediaProbe.available === true; const mediaEngineReason = () => capabilities?.capabilities.convert.reason || capabilities?.capabilities.mediaProbe.reason || "媒体引擎不可用"; const mediaEngineUnavailableText = () => connectionState === "online" ? `Companion 在线但媒体引擎不可用：${esc(mediaEngineReason())}` : "Companion 离线；媒体引擎状态未知，已禁用媒体操作。"; const mediaEngineNotice = () => !mediaEngineAvailable() ? `<p class="offline-text">${mediaEngineUnavailableText()}</p>` : ""; const mediaControlsDisabled = () => !client.paired || !mediaEngineAvailable(); const stateLabel = () => connectionState === "online" ? (client.paired || lifecycle?.pairing.state === "paired" ? (mediaEngineAvailable() ? "Companion 已配对" : "Companion 已配对 · 媒体引擎不可用") : "Companion 在线 · 待配对") : connectionState === "connecting" ? "正在连接 Companion" : "Companion 离线 · 启动服务";
type ServiceStage = "offline" | "connecting" | "pending" | "paired";
const serviceStage = (): ServiceStage => connectionState === "connecting" ? "connecting" : connectionState !== "online" ? "offline" : client.paired || lifecycle?.pairing.state === "paired" ? "paired" : "pending";
function isEditingField(): boolean { const active = document.activeElement; return active instanceof HTMLInputElement || active instanceof HTMLTextAreaElement || active instanceof HTMLSelectElement; }
function serviceJourney(): string { const stages: Array<[ServiceStage, string]> = [["offline", "未启动"], ["connecting", "正在连接"], ["pending", "在线待配对"], ["paired", "已配对"]]; const active = stages.findIndex(([stage]) => stage === serviceStage()); return `<div class="service-journey" role="list" aria-label="Companion 连接进度">${stages.map(([stage, label], index) => `<span role="listitem" class="${index < active ? "is-complete" : index === active ? "is-active" : ""}" data-stage="${stage}">${label}</span>`).join("")}</div>`; }
function showNotice(message: string, persistent = false): void { noticeLifecycle.show(message, persistent); }
function startRecoveryPanel(): string { if (!startRecoveryVisible) return ""; return `<div class="start-recovery" role="status"><strong>Companion 尚未运行</strong><p>Toolkit 只连接已经运行的 Companion，不安装启动协议，也不执行本机程序。确认 Companion 后台服务已运行后再重新检测。</p><div class="row"><button class="secondary" data-action="refresh-companion">重新检测</button></div></div>`; }
function pairingPanel(): string { const journey = `${serviceJourney()}<p class="service-shared-note">Toolkit 与 Player 共用同一 Companion，只需在任一官方客户端配对一次。</p>`; if (connectionState !== "online") return card("Companion 共享服务", `${journey}<p class="offline-text">${connectionState === "connecting" ? "正在检测本机服务，请稍候…" : "Companion 尚未运行，Web 功能不受影响。"}</p>${lastConnectionError ? `<p class="muted">连接错误：${esc(lastConnectionError)}</p>` : ""}${startRecoveryPanel()}${startRecoveryVisible ? "" : `<button class="secondary" data-action="refresh-companion" ${connectionState === "connecting" ? "disabled" : ""}>${connectionState === "connecting" ? "正在连接" : "重新检测"}</button>`}`, "service-card"); if (client.paired || lifecycle?.pairing.state === "paired") return card("Companion 共享服务", `${journey}<p class="online-text">共享服务已配对</p><p class="muted">另一官方客户端会自动继承；全局撤销会立即使两个客户端失效。</p><button class="secondary" data-action="revoke-suite">撤销整个 Suite 授权</button><button class="secondary" data-action="forget-session">仅结束本窗口会话</button>`, "service-card"); return card("Companion 共享服务", `${journey}${pairingId ? `<p>Media Companion 已把本次配对码安全显示给这个官方 Toolkit。</p><p class="online-text"><strong>Media Companion 配对码：${esc(pairingCode)}</strong></p><div class="row"><input id="pair-code" type="text" maxlength="6" inputmode="numeric" pattern="[0-9]*" autocomplete="one-time-code" aria-label="六位配对码" placeholder="000000"><button class="secondary" data-action="confirm-pair">确认</button></div>` : `<p>服务已在线，请在 Toolkit 或 Player 任一处完成一次配对。</p><button class="secondary" data-action="request-pair">开始配对</button>`}`, "service-card"); }
function renderHome(): string { const offline = connectionState !== "online"; const engine = offline ? "Companion 离线；媒体引擎状态未知，已禁用媒体操作。" : mediaEngineAvailable() ? "媒体引擎已就绪 · Probe / Auto / Remux / Video / Audio / Full" : `Companion 在线但媒体引擎不可用：${esc(mediaEngineReason())}`; const torrent = offline ? "Companion 离线；Torrent 引擎状态未知，不能创建任务。" : "单文件载荷可交给 Chrome 原生另存为，或交给 Companion 内置下载器保存到唯一受控目录。"; return `<div class="hero"><div><span class="badge">0.2.9 · 双模式下载与可信取消 P0</span><h2>本地媒体工作台</h2><p>媒体文件只流向 127.0.0.1 上的 Companion。下载目标不接受网页路径：浏览器模式由 Chrome 原生另存为选择，Companion 模式只使用任务私有受控目录。</p></div><div class="architecture"><span>启动共享服务</span><b>→</b><span>只配对一次</span><b>→</b><span>受控本地任务</span></div></div><div class="grid three">${pairingPanel()}${card("媒体引擎", `<p>${engine}</p><a href="#convert">打开转换工作台 →</a>`)}${card("Torrent 边界", `<p>${torrent}</p><a href="#torrent">打开磁力工具 →</a>`)}</div>`; }
function mediaPicker(label: string): string { return `<label class="dropzone"><input id="media-file" type="file" ${!mediaEngineAvailable() ? "disabled" : ""}><span>＋</span><strong>${selectedMedia ? esc(selectedMedia.name) : label}</strong><small>${selectedMedia ? `${selectedMedia.bytes.toLocaleString()} bytes · 已安全上传` : mediaEngineAvailable() ? "浏览器只上传你明确选择的文件" : mediaEngineUnavailableText()}</small></label>`; }
function renderConvert(): string { const plan = planResult?.plan; return `<div class="page-intro"><h2>转换</h2><p>先查看路线、速度、耗电与空间估计，再创建持久任务。</p>${mediaEngineNotice()}</div><div class="grid two">${mediaPicker("选择要转换的媒体")}${card("固定转换方案", `<label>路线<select id="convert-mode" ${!mediaEngineAvailable() ? "disabled" : ""}><option value="auto">Auto</option><option value="remux">Remux</option><option value="video">Video Convert</option><option value="audio">Audio Convert</option><option value="full">Full Convert</option></select></label><div class="row"><button class="secondary" data-action="plan" ${!selectedMedia || mediaControlsDisabled() ? "disabled" : ""}>分析方案</button><button class="secondary" data-action="convert" ${!selectedMedia || mediaControlsDisabled() ? "disabled" : ""}>创建转换任务</button></div>${plan ? `<dl class="metadata"><dt>路线</dt><dd>${esc(plan.route)}</dd><dt>速度</dt><dd>${esc(plan.estimatedSpeed)}</dd><dt>耗电</dt><dd>${esc(plan.estimatedEnergy)}</dd><dt>预计空间</dt><dd>${Number(plan.estimatedOutputBytes).toLocaleString()} bytes</dd></dl>` : `<p class="muted">${mediaEngineAvailable() ? "尚未分析。估计值不是承诺。" : mediaEngineUnavailableText()}</p>`}`)}</div>`; }
function renderInfo(): string { const latest = tasks.find(task => task.kind === "analysis" && task.result); const result = latest?.result; return `<div class="page-intro"><h2>媒体信息</h2><p>真实 ffprobe 结果，包括容器、时长与轨道。</p>${mediaEngineAvailable() ? `<p class="online-text">媒体引擎已就绪 · FFmpeg/ffprobe 可用</p>` : mediaEngineNotice()}</div><div class="grid two">${mediaPicker("选择要探测的媒体")}${card("探测结果", `<button class="secondary" data-action="probe" ${!selectedMedia || mediaControlsDisabled() ? "disabled" : ""}>创建探测任务</button>${result ? `<dl class="metadata"><dt>Container</dt><dd>${esc(result.container)}</dd><dt>Duration</dt><dd>${esc(result.durationSeconds)} s</dd><dt>Video</dt><dd>${esc(result.video?.map(item => `${item.codec} ${item.width}×${item.height}`).join(", ") || "无")}</dd><dt>Audio</dt><dd>${esc(result.audio?.map(item => item.codec).join(", ") || "无")}</dd><dt>Subtitle</dt><dd>${esc(result.subtitles?.map(item => item.codec).join(", ") || "无")}</dd></dl>` : `<p class="muted">${mediaEngineAvailable() ? "任务完成后在此显示结果。" : mediaEngineUnavailableText()}</p>`}`)}</div>`; }
function renderTorrent(): string { return `<div class="page-intro"><h2>磁力 / Torrent</h2><p>Magnet 只先解析完整文件列表。单选后可使用 Chrome 原生“另存为”，或 Companion 内置下载器的唯一受控目录；当前不支持选择其他本地目录。</p></div><div class="grid two">${card("解析 Magnet", `<label>Magnet URI<textarea id="magnet-input" rows="5" placeholder="magnet:?xt=urn:btih:…"></textarea></label><button class="secondary" data-action="add-magnet" ${!client.paired ? "disabled" : ""}>创建解析任务</button>`)}${card("固定安全边界", `<dl class="metadata"><dt>浏览器目标</dt><dd>由 Chrome 原生“另存为”界面选择</dd><dt>Companion 目标</dt><dd>Companion 受控目录（当前唯一授权位置）</dd><dt>第三方下载器</dt><dd>不包含 aria2、qBittorrent 或其他集成</dd><dt>持续禁用</dt><dd>任意路径 / 公共入站 / WebSeed / UPnP / NAT-PMP / LSD / WebRTC</dd></dl>`)}</div>`; }
const bytes = (value?: number) => Number(value ?? 0).toLocaleString();
const speed = (value?: number) => value ? `${(value / 1024).toFixed(1)} KiB/s` : "—";
function effectiveDownload(task: TaskSummary): DownloadView | undefined {
  const value = task.download; const browser = browserDownloads.get(task.id);
  if (!value || value.mode !== "browser" || !browser) return value;
  return { ...value, state: browser.state, bytesReceived: browser.bytesReceived, totalBytes: browser.totalBytes, speed: 0, peers: 0, error: browser.error };
}
function taskActions(task: TaskSummary): string {
  const download = effectiveDownload(task);
  if (download?.state === "canceling") return "正在取消…";
  if (download?.state === "paused") return `<button data-task="${task.id}" data-task-action="resume">继续</button><button data-task="${task.id}" data-task-action="cancel">取消</button>`;
  if (download && ["waiting_destination", "queued", "connecting", "downloading"].includes(download.state)) return `${download.mode === "browser" && ["connecting", "downloading"].includes(download.state) ? `<button data-task="${task.id}" data-task-action="pause">暂停</button>` : download.mode === "companion" ? `<button data-task="${task.id}" data-task-action="pause">暂停</button>` : ""}<button data-task="${task.id}" data-task-action="cancel">取消</button>`;
  if (download?.mode === "browser") return "—";
  if (["queued", "running"].includes(task.status)) return `${task.kind === "torrent" ? `<button data-task="${task.id}" data-task-action="pause">暂停</button>` : ""}<button data-task="${task.id}" data-task-action="cancel">取消</button>`;
  if (task.status === "paused") return `<button data-task="${task.id}" data-task-action="resume">继续</button><button data-task="${task.id}" data-task-action="cancel">取消</button>`;
  if (["failed", "canceled", "cancelled"].includes(task.status)) return `<button data-task="${task.id}" data-task-action="retry">重试</button>`;
  return "—";
}
function torrentFiles(task: TaskSummary): Array<{ index: number; name: string; bytes: number }> { const source = task.result?.files ?? task.metadata?.files; return Array.isArray(source) ? source.filter(file => Number.isInteger(file?.index) && typeof file?.name === "string" && Number.isFinite(file?.bytes)) : []; }
function derivedTorrentFiles(task: TaskSummary): Array<{ index: number; name: string; bytes: number }> {
  const source = task.result?.files;
  if (!Array.isArray(source) || !source.length) return [];
  const files = source.filter(file => Number.isInteger(file?.index) && typeof file?.name === "string" && file.name.length > 0 && Number.isFinite(file?.bytes) && file.bytes >= 0);
  if (files.length !== source.length || new Set(files.map(file => file.index)).size !== files.length) return [];
  return files;
}
function metadataIneligibilityReason(task: TaskSummary): string {
  if (task.status !== "completed") return "任务未处于已完成状态";
  if (task.result?.metadataOnly !== true) return "缺少 metadata-only 完成标记";
  if (!derivedTorrentFiles(task).length) return "缺少完整合法 result.files";
  return "";
}
function metadataSelection(task: TaskSummary): string {
  const files = derivedTorrentFiles(task); if (metadataIneligibilityReason(task) || !files.length) return "";
  const selectedIndex = torrentSelections.get(task.id); const selected = files.find(file => file.index === selectedIndex); const mode = torrentDeliveryModes.get(task.id);
  const controlled = downloadLocations.find(location => location.id === "companion-controlled");
  const disabled = !selected || !mode || !client.paired || busy || (mode === "companion" && !controlled);
  return `<fieldset class="torrent-selection"><legend>选择一个文件和下载模式</legend><div class="torrent-file-list">${files.map(file => `<label><input type="radio" name="torrent-${task.id}" data-metadata-task-id="${task.id}" data-file-index="${file.index}" ${selectedIndex === file.index ? "checked" : ""}><span>${esc(file.name)}<small>${bytes(file.bytes)} bytes · index ${file.index}</small></span></label>`).join("")}</div><div class="delivery-modes"><label><input type="radio" name="delivery-${task.id}" data-delivery-task-id="${task.id}" value="browser" ${mode === "browser" ? "checked" : ""}><span><strong>浏览器下载</strong><small>由 Chrome 原生“另存为”界面选择；重名自动 uniquify。</small></span></label><label><input type="radio" name="delivery-${task.id}" data-delivery-task-id="${task.id}" value="companion" ${mode === "companion" ? "checked" : ""}><span><strong>Companion 本地下载</strong><small>${esc(controlled?.label ?? "Companion 未返回授权位置")}；当前不支持选择其他本地目录。</small></span></label></div><button data-action="download-selected" data-task="${task.id}" ${disabled ? "disabled" : ""}>开始所选下载</button><small>默认不选择文件或模式；浏览器不会提交 Magnet、raw path、tracker、peer 或 DHT。</small></fieldset>`;
}
function torrentDetails(task: TaskSummary): string {
  const isDownloadTask = Boolean(task.summary?.sourceMetadataTaskId || task.summary?.selectedFile || task.result?.selectedFile);
  const files = torrentFiles(task);
  if (!isDownloadTask && (task.result?.metadataOnly === true || task.summary?.networkScope === "public-metadata-only" || files.length)) {
    if (!files.length) return "";
    const reason = metadataIneligibilityReason(task);
    const nextStep = reason ? `<div class="torrent-legacy-guidance" role="note"><strong>此旧任务不能安全派生下载</strong><p>原因：${esc(reason)}。请创建新的 metadata-only 解析任务，再从其完整文件列表单选下载。</p><button class="secondary" data-action="new-metadata-task">新建仅元数据解析任务</button><small>不会重发或显示旧任务内部 Magnet。</small></div>` : metadataSelection(task);
    return `<div class="torrent-details"><strong>${esc(task.result?.name ?? task.metadata?.name ?? "磁力内容")}</strong><div class="torrent-file-summary">${files.map(file => `<span>${esc(file.name)} · ${bytes(file.bytes)} bytes · index ${file.index}</span>`).join("")}</div>${nextStep}</div>`;
  }
  const download = effectiveDownload(task); const selected = download?.file ?? task.summary?.selectedFile ?? task.result?.selectedFile; if (!selected) return "";
  const received = download?.bytesReceived ?? task.downloadedBytes ?? task.result?.downloadedBytes ?? 0; const total = download?.totalBytes ?? task.totalBytes ?? selected.bytes ?? 0; const output = task.result?.output;
  const metrics = download?.mode === "browser" ? `${bytes(received)} / ${bytes(total)} bytes · 状态来自 chrome.downloads` : `${bytes(received)} / ${bytes(total)} bytes · ${speed(download?.speed ?? task.downloadSpeed)} · peer ${Number(download?.peers ?? task.peers ?? 0)}`;
  return `<div class="torrent-details"><strong>选中文件：${esc(selected.name)} · ${bytes(selected.bytes)} bytes</strong>${download ? `<span>模式：${download.mode === "browser" ? "浏览器下载" : "Companion 内置下载器"} · 目标：${esc(download.location.label)}</span><span>可信状态：${esc(download.state)} · ${metrics}</span>` : `<span>${metrics}</span>`}${download?.error ? `<span class="task-error">${esc(download.error.code)} · ${esc(download.error.message)}</span>` : ""}${output && download?.mode !== "browser" ? `<span class="controlled-output">完成结果：${esc(output.name)} · ${bytes(output.bytes)} bytes · 已保存到 Companion 受控目录</span>` : ""}</div>`;
}
function renderTasks(): string {
  const rows = tasks.map(task => {
    const download = effectiveDownload(task); const state = download?.state ?? (task.status === "cancelled" ? "canceled" : task.status); const progress = download?.totalBytes ? download.bytesReceived / download.totalBytes : task.progress ?? 0;
    return `<div class="task-row"><div><strong>${esc(task.kind)}</strong><small>${esc(download?.file.name ?? task.summary?.selectedFile?.name ?? task.summary?.file?.name ?? task.summary?.source ?? task.id.slice(0, 8))}</small></div><span class="status-${state}">${esc(state)}<small>${esc(task.stage)}</small></span><div><progress max="1" value="${progress}"></progress><small>${Math.round(progress * 100)}%${download ? ` · ${bytes(download.bytesReceived)} / ${bytes(download.totalBytes)} bytes` : ""}</small></div><div class="row mini">${taskActions(task)}</div>${task.error && !download?.error ? `<p class="task-error">${esc(task.error.code)} · ${esc(task.error.message)}</p>` : ""}${task.kind === "torrent" ? torrentDetails(task) : ""}</div>`;
  }).join("");
  return `<div class="page-intro"><h2>任务中心</h2><p>浏览器模式状态以 chrome.downloads 为准；Companion 模式状态以 WebTorrent 与受控 output 为准。取消先进入 canceling，确认资源释放后才显示 canceled。</p><button class="secondary" data-action="refresh-tasks" ${!client.paired ? "disabled" : ""}>刷新</button></div><div class="task-list">${rows || card("暂无任务", "<p>创建分析、转换或 Magnet 元数据任务后会显示在这里。</p>")}</div>`;
}
function renderSettings(): string { return `<div class="page-intro"><h2>设置与安全</h2></div><div class="grid two">${pairingPanel()}${card("固定边界", `<dl class="metadata"><dt>API / listener</dt><dd>127.0.0.1:32145 / loopback</dd><dt>浏览器下载</dt><dd>Chrome 原生另存为；扩展不显示或保存绝对 filename</dd><dt>Companion 下载</dt><dd>仅 companion-controlled；当前不支持其他本地目录</dd><dt>第三方下载器</dt><dd>不包含 aria2、qBittorrent 或其他集成</dd><dt>持续禁用</dt><dd>任意路径 / 公共入站 / WebSeed / UPnP / NAT-PMP / LSD / WebRTC</dd></dl>`)}</div>`; }
const renderers: Record<RouteId, () => string> = { home: renderHome, convert: renderConvert, torrent: renderTorrent, info: renderInfo, tasks: renderTasks, settings: renderSettings };
function render(route = currentRoute()): void { nav.innerHTML = routes.map(item => `<button class="nav-item ${item.id === route ? "is-active" : ""}" data-route="${item.id}" type="button"><span>${item.icon}</span>${item.label}</button>`).join(""); title.textContent = routes.find(item => item.id === route)!.label; content.innerHTML = renderers[route](); location.hash = route; }
function applyState(next: CompanionState, nextLifecycle?: CompanionLifecycleStatus): void { const stateChanged = connectionState !== next; connectionState = next; lifecycle = nextLifecycle; if (next === "online") startRecoveryVisible = false; if (stateChanged) noticeLifecycle.dismiss(); if (nextLifecycle) connectedService = `${nextLifecycle.service.name} ${nextLifecycle.service.version}`; document.querySelector("#top-status")!.textContent = stateLabel(); document.querySelector("#footer-status")!.textContent = next === "online" ? `${connectedService} · ${client.paired ? "短期授权" : nextLifecycle?.pairing.state === "paired" ? "已共享配对" : "待配对"}` : "离线 · 等待 Companion"; document.querySelectorAll<HTMLElement>("[data-connection-dot]").forEach(dot => { dot.classList.toggle("dot-online", next === "online"); dot.classList.toggle("dot-offline", next !== "online"); }); }
async function refresh(): Promise<void> {
  try {
    const nextLifecycle = await client.lifecycleStatus();
    lastConnectionError = "";
    applyState("online", nextLifecycle);
    try { capabilities = await client.capabilities(); } catch { capabilities = undefined; }
    if (!client.paired && nextLifecycle.pairing.state === "paired") {
      try { await client.bootstrapSession(); } catch { client.clearSession(); }
    }
    if (client.paired) {
      try {
        [tasks, downloadLocations] = await Promise.all([client.tasks(), client.downloadLocations()]);
        try { const background = await backgroundMessage<{ records: BrowserDownloadRecord[] }>({ type: "browser-download/list" }); browserDownloads.clear(); for (const record of background.records ?? []) browserDownloads.set(record.taskId, record); } catch { browserDownloads.clear(); }
      } catch (error) {
        if (error instanceof CompanionApiError && error.status === 401 && nextLifecycle.pairing.state === "paired") {
          try { await client.bootstrapSession(); [tasks, downloadLocations] = await Promise.all([client.tasks(), client.downloadLocations()]); } catch { client.clearSession(); tasks = []; downloadLocations = []; }
        } else { tasks = []; downloadLocations = []; }
      }
    }
  } catch (error) { lastConnectionError = error instanceof Error ? error.message : String(error); capabilities = undefined; applyState("offline"); }
  if (!busy && !isEditingField()) render();
}
async function action(name: string, target: HTMLElement): Promise<void> {
  if (busy) return; busy = true;
  try {
    if (name === "refresh-companion") { connectionState = "connecting"; render(); showNotice("正在检测已经运行的 Companion…", true); await refresh(); if (serviceStage() === "offline") { startRecoveryVisible = true; showNotice("仍未检测到 Companion。请确认 Companion 后台服务已运行，再重新检测。", true); } }
    else if (name === "refresh-tasks") { await refresh(); showNotice(`已从 Companion 读取 ${tasks.length} 个任务。`); }
    else if (name === "request-pair") { const value = await client.requestPairing(); pairingId = value.pairingId ?? ""; pairingCode = value.pairingCode ?? ""; showNotice(value.inherited ? "已自动继承 SM Media Suite 共享授权。" : pairingCode ? "Media Companion 配对码已显示在此官方 Toolkit。" : "配对码未能交付；请重新开始配对。"); }
    else if (name === "confirm-pair") { await client.confirmPairing(pairingId, (document.querySelector<HTMLInputElement>("#pair-code")?.value ?? "").trim()); pairingId = ""; pairingCode = ""; showNotice("本地短期会话已建立。"); }
    else if (name === "revoke-suite") { if (!window.confirm("撤销后 Toolkit 与 Player 都需要重新完成一次配对。是否撤销整个 SM Media Suite 授权？")) return; await client.revokeSuiteAuthorization(); pairingId = ""; pairingCode = ""; tasks = []; showNotice("已撤销整个 SM Media Suite 授权；两个客户端的会话均已失效。"); }
    else if (name === "forget-session") { client.clearSession(); tasks = []; }
    else if (["plan", "convert", "probe"].includes(name) && !mediaEngineAvailable()) { showNotice(`Companion 在线但媒体引擎不可用：${mediaEngineReason()}`); return; }
    else if (name === "plan") planResult = await client.plan(selectedMedia!.id, document.querySelector<HTMLSelectElement>("#convert-mode")!.value);
    else if (name === "convert") { await client.convert(selectedMedia!.id, document.querySelector<HTMLSelectElement>("#convert-mode")!.value); location.hash = "tasks"; }
    else if (name === "probe") { await client.probe(selectedMedia!.id); location.hash = "tasks"; }
    else if (name === "new-metadata-task") { location.hash = "torrent"; showNotice("请在 Magnet/Torrent 页创建新的仅元数据解析任务；旧任务内容不会被重发。", true); }
    else if (name === "add-magnet") { const magnet = document.querySelector<HTMLTextAreaElement>("#magnet-input")!.value.trim(); if (!magnet) { showNotice("请先输入 Magnet URI。"); return; } const created = await client.addTorrent({ magnet, metadataOnly: true }); tasks = [created, ...tasks.filter(task => task.id !== created.id)]; showNotice("磁力解析任务已创建；只解析文件列表，不自动下载内容。"); location.hash = "tasks"; }
    else if (name === "download-selected") {
      const source = tasks.find(task => task.id === target.dataset.task);
      const selectedIndex = source ? torrentSelections.get(source.id) : undefined; const mode = source ? torrentDeliveryModes.get(source.id) : undefined;
      const selected = source && selectedIndex !== undefined ? derivedTorrentFiles(source).find(file => file.index === selectedIndex) : undefined;
      if (!source || source.kind !== "torrent" || source.status !== "completed" || source.result?.metadataOnly !== true || !selected || !mode) { showNotice("源元数据任务、单文件选择或下载模式已失效，请刷新后重新选择。"); return; }
      if (!client.paired) { showNotice("请先配对 Companion。"); return; }
      const targetFact = mode === "browser" ? "目标由 Chrome 原生“另存为”界面选择；重名自动 uniquify，Toolkit 不读取最终绝对路径。" : "目标为 Companion 受控目录（当前唯一授权位置）；当前不支持选择其他本地目录。";
      const confirmed = window.confirm(`将以${mode === "browser" ? "浏览器下载" : "Companion 内置下载器"}下载“${selected.name}”（${bytes(selected.bytes)} bytes）。\n\n${targetFact}\n\n这会产生公共出站 BitTorrent 载荷流量；不会开放端口，不会修改防火墙，不会使用 WebSeed。是否继续？`);
      if (!confirmed) return;
      const created = await client.createTorrentDownload(source.id, selected.index, mode, mode === "companion" ? "companion-controlled" : undefined); tasks = [created.task, ...tasks.filter(task => task.id !== created.task.id)];
      if (mode === "browser") {
        if (!created.browserDownload) { await client.taskAction(created.task.id, "cancel"); throw new Error("Companion 未返回浏览器下载 ticket。"); }
        const started = await backgroundMessage<{ record: BrowserDownloadRecord }>({ type: "browser-download/start", payload: { taskId: created.task.id, url: created.browserDownload.url, suggestedName: created.browserDownload.suggestedName, bytes: created.browserDownload.bytes } });
        browserDownloads.set(created.task.id, started.record);
        if (started.record.state === "failed") await client.taskAction(created.task.id, "cancel");
        showNotice(started.record.state === "failed" ? `${started.record.error?.code ?? "BROWSER_DOWNLOAD_START_FAILED"}：${started.record.error?.message ?? "Chrome 未开始下载。"}` : "Chrome 原生另存为下载已创建；状态与取消由 chrome.downloads 回读。");
      } else showNotice("Companion 内置单文件下载已创建；位置固定为受控目录。");
      location.hash = "tasks";
    }
    await refresh();
  } catch (error) { const message = error instanceof CompanionApiError && error.code === "ORIGIN_NOT_ALLOWED" ? "此 Toolkit 不是已登记的官方预览包。请安装本预览包提供的 Toolkit 后重试。" : error instanceof CompanionApiError ? `${error.code}：${error.message}` : error instanceof Error ? error.message : String(error); showNotice(message); }
  finally { busy = false; render(); }
}

nav.addEventListener("click", event => { const route = (event.target as HTMLElement).closest<HTMLElement>("[data-route]")?.dataset.route ?? ""; if (isRoute(route)) render(route); });
content.addEventListener("input", event => { const input = event.target as HTMLInputElement; if (input.id === "pair-code") input.value = input.value.replace(/\D/g, "").slice(0, 6); });
content.addEventListener("change", async event => {
  const input = event.target as HTMLInputElement;
  if (input.dataset.deliveryTaskId && (input.value === "browser" || input.value === "companion")) {
    const source = tasks.find(task => task.id === input.dataset.deliveryTaskId);
    if (source?.status === "completed" && source.result?.metadataOnly === true) torrentDeliveryModes.set(source.id, input.value);
    render(); return;
  }
  if (input.dataset.metadataTaskId && input.dataset.fileIndex !== undefined) {
    const source = tasks.find(task => task.id === input.dataset.metadataTaskId); const index = Number(input.dataset.fileIndex);
    if (source?.status === "completed" && source.result?.metadataOnly === true && Number.isInteger(index) && derivedTorrentFiles(source).some(file => file.index === index)) torrentSelections.set(source.id, index);
    render(); return;
  }
  if (!input.files?.[0] || !client.paired) return;
  if (input.id === "media-file" && !mediaEngineAvailable()) { showNotice(`Companion 在线但媒体引擎不可用：${mediaEngineReason()}`); return; }
  busy = true;
  try { selectedMedia = await client.upload(input.files[0]); planResult = undefined; showNotice("文件已流式交给本地 Companion。"); }
  catch (error) { showNotice(error instanceof CompanionApiError && error.code === "MEDIA_ENGINE_DISABLED" ? `Companion 在线但媒体引擎不可用：${mediaEngineReason()}` : error instanceof Error ? error.message : String(error)); }
  finally { busy = false; render(); }
});
async function performTaskAction(taskId: string, taskAction: "pause" | "resume" | "cancel" | "retry"): Promise<void> {
  const task = tasks.find(value => value.id === taskId); const download = task ? effectiveDownload(task) : undefined;
  if (download?.mode === "browser" && taskAction !== "retry") {
    const response = await backgroundMessage<{ record: BrowserDownloadRecord }>({ type: `browser-download/${taskAction}`, taskId }); browserDownloads.set(taskId, response.record);
    if (taskAction === "cancel") await client.taskAction(taskId, "cancel");
  } else await client.taskAction(taskId, taskAction);
  await refresh();
}
content.addEventListener("click", event => { const element = (event.target as HTMLElement).closest<HTMLElement>("[data-action],[data-task-action]"); if (!element) return; const taskAction = element.dataset.taskAction as "pause" | "resume" | "cancel" | "retry" | undefined; if (taskAction) { busy = true; performTaskAction(element.dataset.task!, taskAction).catch(error => showNotice(error instanceof CompanionApiError ? `${error.code}：${error.message}` : error instanceof Error ? error.message : String(error))).finally(() => { busy = false; render(); }); } else void action(element.dataset.action!, element); });
extensionRuntime?.onMessage.addListener(message => { if (!message || typeof message !== "object" || !("type" in message) || message.type !== "browser-download/state" || !("record" in message) || !message.record || typeof message.record !== "object" || !("taskId" in message.record) || typeof message.record.taskId !== "string") return; const record = message.record as BrowserDownloadRecord; browserDownloads.set(record.taskId, record); if (!busy && !isEditingField()) render(); });
window.addEventListener("hashchange", () => render()); document.querySelector("#learn-status")!.addEventListener("click", () => { location.hash = "settings"; render("settings"); }); document.querySelector("#companion-status-action")!.addEventListener("click", event => { if (connectionState === "offline") void action("refresh-companion", event.currentTarget as HTMLElement); else { location.hash = "settings"; render("settings"); } }); render(); void refresh(); setInterval(() => { void refresh(); }, 1800);
