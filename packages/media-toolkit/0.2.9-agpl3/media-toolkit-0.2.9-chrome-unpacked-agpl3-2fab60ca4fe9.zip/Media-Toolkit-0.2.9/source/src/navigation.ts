export const routes = [
  { id: "home", label: "首页", icon: "⌂" },
  { id: "convert", label: "转换", icon: "⇄" },
  { id: "torrent", label: "磁力 / Torrent", icon: "↯" },
  { id: "info", label: "媒体信息", icon: "ⓘ" },
  { id: "tasks", label: "任务", icon: "✓" },
  { id: "settings", label: "设置", icon: "⚙" }
] as const;

export type RouteId = (typeof routes)[number]["id"];

export function isRoute(value: string): value is RouteId {
  return routes.some((route) => route.id === value);
}

export function initialRoute(hash: string): RouteId {
  const candidate = hash.replace(/^#/, "");
  return isRoute(candidate) ? candidate : "home";
}
