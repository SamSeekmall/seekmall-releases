import { cpSync, existsSync, mkdirSync, rmSync } from "node:fs";
import { execFileSync } from "node:child_process";

const root = new URL("..", import.meta.url);
const resolve = (part) => new URL(part, root);
if (existsSync(resolve("dist"))) rmSync(resolve("dist"), { recursive: true, force: true });
mkdirSync(resolve("dist"));
execFileSync(process.execPath, ["node_modules/typescript/bin/tsc", "-p", "tsconfig.json"], { cwd: root, stdio: "inherit" });
cpSync(resolve("public"), resolve("dist"), { recursive: true });
