import { createServer, request as requestHttp } from "node:http";
import { createReadStream, existsSync, statSync } from "node:fs";
import { extname, join, normalize } from "node:path";
import { fileURLToPath } from "node:url";

const root = fileURLToPath(new URL("../dist", import.meta.url));
const types = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8" };
createServer((request, response) => {
  const companionRoute = request.url?.match(/^\/companion\/(health|capabilities|tasks)$/);
  if (companionRoute) {
    process.stdout.write(`Toolkit preview bridge GET ${companionRoute[1]}\n`);
    if (request.method !== "GET") { response.writeHead(405, { allow: "GET" }); response.end("Method not allowed"); return; }
    const upstream = requestHttp({ hostname: "127.0.0.1", port: 32145, method: "GET", path: `/api/v1/${companionRoute[1]}` }, upstreamResponse => {
      response.writeHead(upstreamResponse.statusCode ?? 502, {
        "content-type": upstreamResponse.headers["content-type"] ?? "application/json; charset=utf-8",
        "cache-control": "no-store",
        "x-content-type-options": "nosniff"
      });
      upstreamResponse.pipe(response);
    });
    upstream.on("error", () => {
      response.writeHead(503, { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" });
      response.end(JSON.stringify({ error: "COMPANION_OFFLINE" }));
    });
    upstream.end();
    return;
  }
  const requested = request.url === "/" ? "index.html" : decodeURIComponent(request.url ?? "").replace(/^\//, "");
  const path = normalize(join(root, requested));
  if (!path.startsWith(root) || !existsSync(path) || statSync(path).isDirectory()) { response.writeHead(404); response.end("Not found"); return; }
  response.writeHead(200, { "content-type": types[extname(path)] ?? "application/octet-stream" });
  createReadStream(path).pipe(response);
}).listen(4173, "127.0.0.1");
