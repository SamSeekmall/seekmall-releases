import assert from "node:assert/strict";
import test from "node:test";
import { BrowserDownloadController } from "../dist/browser-downloads.js";

function eventHub() { const listeners = []; return { addListener(listener) { listeners.push(listener); }, emit(value) { for (const listener of listeners) listener(value); } }; }
function chromeFixture() {
  const created = eventHub(); const changed = eventHub(); const erased = eventHub(); const items = new Map(); const stored = {}; const calls = { download: [], cancel: [], pause: [], resume: [] }; let nextId = 10;
  const chrome = {
    downloads: {
      async download(options) { calls.download.push(options); const id = nextId++; items.set(id, { id, state: "in_progress", paused: false, canResume: true, bytesReceived: 0, totalBytes: 100, filename: "C:\\Users\\Secret\\absolute.bin" }); created.emit(items.get(id)); return id; },
      async cancel(id) { calls.cancel.push(id); const item = items.get(id); if (item && item.state !== "complete") Object.assign(item, { state: "interrupted", error: "USER_CANCELED", canResume: false }); changed.emit({ id, state: { current: item?.state }, error: { current: item?.error } }); },
      async pause(id) { calls.pause.push(id); const item = items.get(id); if (item) Object.assign(item, { paused: true, canResume: true }); changed.emit({ id, paused: { current: true } }); },
      async resume(id) { calls.resume.push(id); const item = items.get(id); if (item) Object.assign(item, { paused: false, canResume: true }); changed.emit({ id, paused: { current: false } }); },
      async search({ id }) { return items.has(id) ? [{ ...items.get(id) }] : []; },
      onCreated: created, onChanged: changed, onErased: erased,
    },
    storage: { local: { async get(key) { return { [key]: stored[key] }; }, async set(value) { Object.assign(stored, structuredClone(value)); } } },
  };
  return { chrome, items, stored, calls, changed, erased };
}
const flush = () => new Promise(resolve => setTimeout(resolve, 0));

test("Chrome 原生下载状态、取消、竞态和恢复不泄漏绝对 filename", async () => {
  const fixture = chromeFixture(); const emitted = []; const controller = new BrowserDownloadController(fixture.chrome, record => emitted.push(record));
  const started = await controller.start({ taskId: "task-a", url: `http://127.0.0.1:32145/api/v1/browser-download/${"a".repeat(43)}`, suggestedName: "folder/selected?.bin", bytes: 100 });
  assert.deepEqual(fixture.calls.download[0], { url: `http://127.0.0.1:32145/api/v1/browser-download/${"a".repeat(43)}`, filename: "selected_.bin", saveAs: true, conflictAction: "uniquify" });
  assert.equal(started.state, "connecting");
  const item = fixture.items.get(started.downloadId); Object.assign(item, { bytesReceived: 40 }); fixture.changed.emit({ id: item.id, bytesReceived: { current: 40 } }); await flush();
  assert.equal((await controller.query("task-a")).state, "downloading");
  await controller.pause("task-a"); assert.equal((await controller.query("task-a")).state, "paused"); await controller.resume("task-a");
  const canceled = await controller.cancel("task-a"); assert.equal(canceled.state, "canceled"); await controller.cancel("task-a"); assert.equal(fixture.calls.cancel.length, 1);

  const race = await controller.start({ taskId: "task-race", url: `http://127.0.0.1:32145/api/v1/browser-download/${"b".repeat(43)}`, suggestedName: "race.bin", bytes: 100 }); fixture.items.get(race.downloadId).state = "complete";
  assert.equal((await controller.cancel("task-race")).state, "completed");

  const interrupted = await controller.start({ taskId: "task-failed", url: `http://127.0.0.1:32145/api/v1/browser-download/${"c".repeat(43)}`, suggestedName: "failed.bin", bytes: 100 }); Object.assign(fixture.items.get(interrupted.downloadId), { state: "interrupted", error: "NETWORK_FAILED" }); fixture.changed.emit({ id: interrupted.downloadId, state: { current: "interrupted" }, error: { current: "NETWORK_FAILED" } }); await flush(); assert.equal((await controller.query("task-failed")).error.code, "NETWORK_FAILED");

  const lost = await controller.start({ taskId: "task-lost", url: `http://127.0.0.1:32145/api/v1/browser-download/${"d".repeat(43)}`, suggestedName: "lost.bin", bytes: 100 }); fixture.items.delete(lost.downloadId); fixture.erased.emit(lost.downloadId); await flush(); assert.equal((await controller.query("task-lost")).error.code, "BROWSER_DOWNLOAD_STATE_LOST");

  const serialized = JSON.stringify({ stored: fixture.stored, emitted }); assert.doesNotMatch(serialized, /C:\\Users|absolute\.bin|filename/);
  const restored = new BrowserDownloadController(fixture.chrome); const records = await restored.restore(); assert.equal(records.some(record => record.taskId === "task-a" && record.state === "canceled"), true);
});
