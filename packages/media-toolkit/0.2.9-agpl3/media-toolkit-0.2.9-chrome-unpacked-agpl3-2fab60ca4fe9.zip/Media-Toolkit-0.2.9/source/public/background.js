import { BrowserDownloadController } from "./browser-downloads.js";

const controller = new BrowserDownloadController(chrome, record => {
  void chrome.runtime.sendMessage({ type: "browser-download/state", record }).catch(() => {});
});
const restored = controller.restore();

chrome.action.onClicked.addListener(() => {
  void chrome.tabs.create({ url: chrome.runtime.getURL("index.html") });
});

chrome.runtime.onMessage.addListener((message, sender) => {
  if (sender.id !== chrome.runtime.id || !message || typeof message.type !== "string") return undefined;
  return restored.then(async () => {
    if (message.type === "browser-download/start") return { record: await controller.start(message.payload) };
    if (message.type === "browser-download/cancel") return { record: await controller.cancel(message.taskId), cancelCompanionTaskId: message.taskId };
    if (message.type === "browser-download/pause") return { record: await controller.pause(message.taskId) };
    if (message.type === "browser-download/resume") return { record: await controller.resume(message.taskId) };
    if (message.type === "browser-download/query") return { record: await controller.query(message.taskId) };
    if (message.type === "browser-download/list") return { records: controller.list() };
    return undefined;
  });
});
