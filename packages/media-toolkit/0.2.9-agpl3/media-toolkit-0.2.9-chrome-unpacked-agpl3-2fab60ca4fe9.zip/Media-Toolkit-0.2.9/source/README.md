# Media Toolkit 0.2.9 · 双模式下载与可信取消 P0 — SM Media Suite development preview

Media Toolkit is the unpacked Chrome extension client for the loopback-only Media Companion service. It does not expose a public network listener and does not include FFmpeg/ffprobe assets.

## Install and first use

1. Extract the complete Toolkit package.
2. Open `chrome://extensions`, enable **Developer mode**, choose **Load unpacked**, and select the extracted package's `dist` folder (the folder containing `manifest.json`).
3. 确认匹配版本的 Companion 后台服务已经运行。Toolkit 只连接本机服务，不安装自定义启动协议，也不会执行本机程序。
4. When Companion is online, choose **开始配对**. The six-digit **Media Companion 配对码** is visibly delivered in this official Toolkit, then entered here once. SM Player inherits the same Suite authorization and does not pair again.
5. Use **撤销整个 Suite 授权** to invalidate Toolkit and Player authorization together. This differs from ending only the current Toolkit window session.

## Honest capability states

When Companion is offline, the Toolkit shows media and Torrent capabilities as unknown/offline and does not claim they are available. When Companion is online without FFmpeg/ffprobe, media controls stay disabled and the reason is shown; there is no hidden Web fallback for Companion work.

单文件下载提供两种目标：浏览器模式由 Chrome 原生“另存为”界面选择并由 `chrome.downloads` 提供状态；Companion 模式只使用 `companion-controlled` 受控目录。Toolkit 不接收、显示或持久化绝对下载路径，当前不支持选择其他 Companion 本地目录。

This is a local development preview, not independent TECH self-check, QA approval, product acceptance, or a release.
