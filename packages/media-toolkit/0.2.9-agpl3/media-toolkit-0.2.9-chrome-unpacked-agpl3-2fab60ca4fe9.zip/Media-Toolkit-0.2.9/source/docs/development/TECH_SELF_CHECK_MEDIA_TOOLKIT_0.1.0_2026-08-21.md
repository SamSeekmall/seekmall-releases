# Media Toolkit 0.1.0 Chrome Shell — independent TECH self-check

## Identity

- task_id: `MEDIATOOLKIT-TECH-CHROME-SHELL-20260821-001`
- iteration_id: `MEDIATOOLKIT-0.1.0-SHELL`
- work_type: `TECH_SELF_CHECK`
- execution_profile / model / reasoning: `BALANCED` / `gpt-5.6-terra` / `high`
- reviewer: distinct `TECH_SELF_CHECK` subagent
- reviewed candidate commit: `e0891306ee32ab69557885a5ffd6d4f9745f6668`
- reviewed candidate tree: `72417243efa4449c8cc55f5bf32a5f90ed0cad3e`
- reviewed candidate parent: `NONE` (repository root commit)
- reviewed branch: `codex/media-toolkit-0.1.0-shell`

## Result

`TECH_SELF_CHECK_FAIL_CHANGES_REQUIRED`.

The candidate's structural and preview boundaries are consistent with the 0.1.0 shell brief, but the required runnable verification gate cannot be reproduced from the candidate. The candidate declares TypeScript `5.9.2`, contains neither `node_modules` nor a lockfile, and the prescribed commands cannot resolve TypeScript. Offline dependency recovery also failed because the declared package was not in the local npm cache. This is a tooling/reproducibility failure, not a claim of product or Companion failure.

## Checks and evidence

| Check | Result | Evidence |
| --- | --- | --- |
| Exact commit/tree/clean status | PASS | Commit and tree match the supplied identity; tracked worktree clean; parent is empty because this is the initial commit. |
| MV3 full-page action | PASS (static) | `manifest.json` is MV3; `background.js` opens `chrome.runtime.getURL("index.html")`. |
| Six stable navigation pages | PASS (static) | `home`, `convert`, `torrent`, `info`, `tasks`, `settings` are the only route IDs. |
| Offline is normal and non-deceptive | PASS (static) | Default `OfflineCompanionAdapter` reports offline, returns no tasks and rejects task creation. UI says no job/file/network action is performed. |
| Typed versioned API isolation | PASS (static) | `CompanionClient` is typed and the only planned HTTP route prefix is `/api/v1`; the HTTP client is not instantiated by the shell. |
| No local engine / Torrent library / SM Player reuse | PASS (static) | Source and package inventory contain no engine or Player implementation/dependency. |
| Minimal permissions | PASS | Manifest has no `host_permissions` or optional host permissions. |
| Built ZIP inspection | PASS (artefact readback) | ZIP has root application files only: background, compiled JS, HTML, manifest and CSS; no `.git`, dependencies, tests, credentials or extra wrapper directory. Manifest reads `Media Toolkit` / `0.1.0` / MV3. |
| Preview inspection | PASS (visual) | Screenshot clearly shows six navigation entries, a full workspace, and Companion offline as an ordinary state. |
| Typecheck | FAIL | `npm run typecheck` fails: `tsc` is not resolvable. Direct declared compiler path is absent. |
| Focused nav/offline/adapter tests | NOT RUNNABLE | Tests import generated `dist` modules, but the build fails before compilation for the same missing TypeScript dependency. |
| Extension build | FAIL | `node scripts/build.mjs` fails resolving `node_modules/typescript/bin/tsc`. |

## Required minimal correction

1. Add a committed lockfile and verify that the declared TypeScript version is reproducibly available through the project scripts, or otherwise amend the approved local build contract.
2. Re-run the declared typecheck, focused tests and one Extension build on the repaired candidate.
3. Keep the verified product boundaries unchanged: MV3 full-page shell, six pages, default normal offline state, typed `/api/v1` adapter only, no engine/Torrent library/SM Player reuse, and minimal permissions.

## Boundaries and unverified scope

- This is not QA PASS, user acceptance, a real Chrome-install test, or a Companion/API/media/Torrent test.
- No browser extension was installed; no network, Companion, media file, Torrent, account, push, deploy or release action was performed.
- The existing local ZIP was read only; it is not re-certified as a final trial package until the required reproducible checks pass.

## Next owner

`TECH_IMPLEMENTATION` — resolve the reproducible dependency/build gate in the same iteration, then resubmit a new frozen candidate for independent TECH self-check.
