# Media Toolkit 0.1.0 Chrome Shell — TECH handoff

## Identity and scope

- task_id: `MEDIATOOLKIT-TECH-CHROME-SHELL-20260821-001`
- iteration_id: `MEDIATOOLKIT-0.1.0-SHELL`
- work_type: `TECH_DEVELOPMENT`
- execution_profile / model / reasoning: `BALANCED` / `gpt-5.6-terra` / `high`
- implementation: `TECH_IMPLEMENTATION` subagent
- status: `USER_PREVIEW_CANDIDATE_R1_PENDING_TECH_SELF_CHECK`
- product version: `Media Toolkit 0.1.0`

This is an independent MV3 Chrome extension project. It is a Companion API client shell only: it contains no FFmpeg, no Torrent library, no copied SM Player media engine, no host permissions, and no default network transport.

## Visible result

- Toolbar action opens `index.html` in a full-page extension tab.
- Six pages are present: Home, Convert, Magnet/Torrent, Media Info, Tasks, and Settings.
- The header and footer report **Companion offline** as a normal state.
- Offline pages expose their intended forms and capability boundaries, but do not create mock jobs or report fake success.
- `CompanionClient` is typed. `OfflineCompanionAdapter` is the default. A future opt-in HTTP adapter is constrained to versioned `/api/v1/*` endpoints.

## Implementation evidence

- preview screenshot: `docs/development/MEDIA_TOOLKIT_0.1.0_SHELL_PREVIEW_2026-08-21.png`
- trial artefacts: `releases/Media-Toolkit-v0.1.0-Chrome-unpacked/` and `releases/Media-Toolkit-v0.1.0-Chrome-extension.zip`
- manifest: MV3, version `0.1.0`, no `host_permissions`, no optional host permission requested.

## Checks completed by implementation

| Check | Result |
| --- | --- |
| Locked deterministic dependency setup | PASS (`package-lock.json`, `npm ci`) |
| TypeScript typecheck | PASS |
| Focused navigation / offline adapter / manifest tests | PASS (`3/3`) |
| Extension build | PASS |
| Local visual navigation inspection | PASS (`6/6` routes) |

## Deliberately not covered

- Real Chrome extension installation and toolbar-click runtime.
- Companion installation, API authentication, any localhost permission, real media or Torrent operation.
- Responsive/accessibility audit, complete regression, QA, product acceptance, release, deployment and push.

## Required next gate

The first independent TECH self-check correctly rejected the original candidate because it lacked a committed lockfile. This R1 candidate adds only `package-lock.json` plus this evidence correction. An independent `TECH_SELF_CHECK` must bind a fresh report to the exact R1 commit and independently rerun the declared small checks before this may be called `READY_FOR_QA`. This document does not claim QA PASS or user acceptance.
